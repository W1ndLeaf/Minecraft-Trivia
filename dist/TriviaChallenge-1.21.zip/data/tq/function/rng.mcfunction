execute store result score #rnd tq_cfg run random value 0..2147483647
