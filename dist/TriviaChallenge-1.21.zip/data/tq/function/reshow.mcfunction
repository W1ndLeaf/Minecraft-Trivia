scoreboard players set @s tq_wait 0
function tq:show_q
