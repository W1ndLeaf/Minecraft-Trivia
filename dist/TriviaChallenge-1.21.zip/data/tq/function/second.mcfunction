scoreboard players set #clock tq_cfg 0
function tq:enable_triggers
execute as @a[tag=tq_e_nv] run effect give @s minecraft:night_vision infinite 0 true
execute as @a[tag=tq_e_sf] run effect give @s minecraft:slow_falling infinite 0 true
execute as @a[scores={tq_t_jump=1..}] run function tq:timers/jump
execute as @a[scores={tq_t_scale=1..}] run function tq:timers/scale
execute as @a[scores={tq_t_reach=1..}] run function tq:timers/reach
execute as @a[scores={tq_t_fall=1..}] run function tq:timers/fall
execute if score #freeze tq_cfg matches 1.. run function tq:freeze/tick
execute if score #sidebar tq_cfg matches 1 as @a[limit=1] run function tq:sidebar
