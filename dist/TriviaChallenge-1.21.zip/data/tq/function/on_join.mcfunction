scoreboard players set @s tq_leave 0
execute if score @s tq_state matches 1.. run scoreboard players set @s tq_wait 2340
