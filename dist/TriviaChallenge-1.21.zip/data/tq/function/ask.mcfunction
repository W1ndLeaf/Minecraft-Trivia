scoreboard players set @s tq_timer 0
function tq:pick
scoreboard players set @s tq_state 1
scoreboard players set @s tq_wait 0
scoreboard players reset @s tq_answer
scoreboard players enable @s tq_answer
function tq:show_q
