scoreboard players set @s tq_deaths 0
function tq:timers/clear_all
