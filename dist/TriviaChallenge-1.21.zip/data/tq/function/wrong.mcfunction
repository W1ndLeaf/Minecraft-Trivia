scoreboard players set @s tq_last 2
scoreboard players add @s tq_wrong 1
playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 0.8
function tq:ans
title @s subtitle {"text":"Correct: ","color":"yellow","extra":[{"nbt":"ans","storage":"tq:tmp","color":"white"}]}
function tq:penalty/random
