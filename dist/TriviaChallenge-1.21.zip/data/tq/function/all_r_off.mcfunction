scoreboard players set r1 tq_on 0
scoreboard players set r2 tq_on 0
scoreboard players set r3 tq_on 0
scoreboard players set r4 tq_on 0
scoreboard players set r5 tq_on 0
scoreboard players set r6 tq_on 0
scoreboard players set r7 tq_on 0
scoreboard players set r8 tq_on 0
scoreboard players set r9 tq_on 0
scoreboard players set r10 tq_on 0
scoreboard players set r11 tq_on 0
scoreboard players set r12 tq_on 0
scoreboard players set r13 tq_on 0
scoreboard players set r14 tq_on 0
scoreboard players set r15 tq_on 0
scoreboard players set r16 tq_on 0
scoreboard players set r17 tq_on 0
scoreboard players set r18 tq_on 0
title @s actionbar {"text":"Every reward is OFF","color":"red"}
tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"every reward is OFF - that side does nothing now.","color":"red"}]}
