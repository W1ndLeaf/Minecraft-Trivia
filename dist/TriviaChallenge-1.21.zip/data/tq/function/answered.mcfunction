scoreboard players operation @s tq_tmp = @s tq_answer
scoreboard players reset @s tq_answer
scoreboard players set @s tq_state 0
scoreboard players set @s tq_timer 0
scoreboard players set @s tq_wait 0
function tq:judge
execute if score #sidebar tq_cfg matches 1 run function tq:sidebar
