execute if score @s tq_qid matches 1 run data merge storage tq:tmp {ans:"A - Ender Chest",ansfull:"A - Ender Chest"}
execute if score @s tq_qid matches 2 run data merge storage tq:tmp {ans:"B - 10",ansfull:"B - 10"}
execute if score @s tq_qid matches 3 run data merge storage tq:tmp {ans:"C - 432",ansfull:"C - 432"}
execute if score @s tq_qid matches 4 run data merge storage tq:tmp {ans:"D - Golden Pickaxe",ansfull:"D - Golden Pickaxe"}
execute if score @s tq_qid matches 5 run data merge storage tq:tmp {ans:"A - Resistance I",ansfull:"A - Resistance I"}
execute if score @s tq_qid matches 6 run data merge storage tq:tmp {ans:"D - Loyalty and Channeling",ansfull:"D - Loyalty and Channeling"}
execute if score @s tq_qid matches 7 run data merge storage tq:tmp {ans:"C - 40",ansfull:"C - 40"}
execute if score @s tq_qid matches 8 run data merge storage tq:tmp {ans:"B - 30 seconds",ansfull:"B - 30 seconds"}
execute if score @s tq_qid matches 9 run data merge storage tq:tmp {ans:"A - An empty shulker box",ansfull:"A - An empty shulker box"}
execute if score @s tq_qid matches 10 run data merge storage tq:tmp {ans:"D - Night Vision",ansfull:"D - Night Vision"}
execute if score @s tq_qid matches 11 run data merge storage tq:tmp {ans:"B - 10",ansfull:"B - 10"}
execute if score @s tq_qid matches 12 run data merge storage tq:tmp {ans:"D - Bed",ansfull:"D - Bed"}
execute if score @s tq_qid matches 13 run data merge storage tq:tmp {ans:"A - Sweeping Edge",ansfull:"A - Sweeping Edge"}
execute if score @s tq_qid matches 14 run data merge storage tq:tmp {ans:"C - Soul Speed",ansfull:"C - Soul Speed"}
execute if score @s tq_qid matches 15 run data merge storage tq:tmp {ans:"C - 100",ansfull:"C - 100"}
execute if score @s tq_qid matches 16 run data merge storage tq:tmp {ans:"B - 1.9 Combat Update",ansfull:"B - 1.9 Combat Update"}
execute if score @s tq_qid matches 17 run data merge storage tq:tmp {ans:"A - Numeric block and item IDs an...",ansfull:"A - Numeric block and item IDs and metadata values"}
execute if score @s tq_qid matches 18 run data merge storage tq:tmp {ans:"C - Y -64 to 319",ansfull:"C - Y -64 to 319"}
execute if score @s tq_qid matches 19 run data merge storage tq:tmp {ans:"D - 1.21 Tricky Trials",ansfull:"D - 1.21 Tricky Trials"}
execute if score @s tq_qid matches 20 run data merge storage tq:tmp {ans:"B - 26.1 Tiny Takeover",ansfull:"B - 26.1 Tiny Takeover"}
execute if score @s tq_qid matches 21 run data merge storage tq:tmp {ans:"A - Alpha 1.2.0, the Halloween Up...",ansfull:"A - Alpha 1.2.0, the Halloween Update"}
execute if score @s tq_qid matches 22 run data merge storage tq:tmp {ans:"C - 1000",ansfull:"C - 1000"}
execute if score @s tq_qid matches 23 run data merge storage tq:tmp {ans:"D - Any depth, even a single block",ansfull:"D - Any depth, even a single block"}
execute if score @s tq_qid matches 24 run data merge storage tq:tmp {ans:"A - Terracotta",ansfull:"A - Terracotta"}
execute if score @s tq_qid matches 25 run data merge storage tq:tmp {ans:"D - Crafter",ansfull:"D - Crafter"}
execute if score @s tq_qid matches 26 run data merge storage tq:tmp {ans:"B - Redstone dust next to it",ansfull:"B - Redstone dust next to it"}
execute if score @s tq_qid matches 27 run data merge storage tq:tmp {ans:"C - It breaks and drops as a sand...",ansfull:"C - It breaks and drops as a sand item"}
execute if score @s tq_qid matches 28 run data merge storage tq:tmp {ans:"A - Water has blast resistance 10...",ansfull:"A - Water has blast resistance 100 and absorbs the explosion rays"}
execute if score @s tq_qid matches 29 run data merge storage tq:tmp {ans:"B - Power 5, stronger than TNT",ansfull:"B - Power 5, stronger than TNT"}
execute if score @s tq_qid matches 30 run data merge storage tq:tmp {ans:"D - Pigstep",ansfull:"D - Pigstep"}
execute if score @s tq_qid matches 31 run data merge storage tq:tmp {ans:"A - 3 to 5",ansfull:"A - 3 to 5"}
execute if score @s tq_qid matches 32 run data merge storage tq:tmp {ans:"D - 3 in-game days",ansfull:"D - 3 in-game days"}
execute if score @s tq_qid matches 33 run data merge storage tq:tmp {ans:"A - 300",ansfull:"A - 300"}
execute if score @s tq_qid matches 34 run data merge storage tq:tmp {ans:"C - 12000",ansfull:"C - 12000"}
execute if score @s tq_qid matches 35 run data merge storage tq:tmp {ans:"C - 500",ansfull:"C - 500"}
execute if score @s tq_qid matches 36 run data merge storage tq:tmp {ans:"B - Mining Fatigue III for 5 minutes",ansfull:"B - Mining Fatigue III for 5 minutes"}
execute if score @s tq_qid matches 37 run data merge storage tq:tmp {ans:"D - An End crystal",ansfull:"D - An End crystal"}
execute if score @s tq_qid matches 38 run data merge storage tq:tmp {ans:"C - Pillager",ansfull:"C - Pillager"}
execute if score @s tq_qid matches 39 run data merge storage tq:tmp {ans:"B - 1 in 3",ansfull:"B - 1 in 3"}
execute if score @s tq_qid matches 40 run data merge storage tq:tmp {ans:"B - 70",ansfull:"B - 70"}
execute if score @s tq_qid matches 41 run data merge storage tq:tmp {ans:"C - 3 to 5 minutes",ansfull:"C - 3 to 5 minutes"}
execute if score @s tq_qid matches 42 run data merge storage tq:tmp {ans:"A - Normal and Hard only",ansfull:"A - Normal and Hard only"}
execute if score @s tq_qid matches 43 run data merge storage tq:tmp {ans:"D - 3 bread or 12 carrots",ansfull:"D - 3 bread or 12 carrots"}
execute if score @s tq_qid matches 44 run data merge storage tq:tmp {ans:"D - Bee",ansfull:"D - Bee"}
execute if score @s tq_qid matches 45 run data merge storage tq:tmp {ans:"A - 0",ansfull:"A - 0"}
execute if score @s tq_qid matches 46 run data merge storage tq:tmp {ans:"D - Gold Vault",ansfull:"D - Gold Vault"}
execute if score @s tq_qid matches 47 run data merge storage tq:tmp {ans:"B - 0 to 1 (a 50% chance of a rod)",ansfull:"B - 0 to 1 (a 50% chance of a rod)"}
execute if score @s tq_qid matches 48 run data merge storage tq:tmp {ans:"C - 20%",ansfull:"C - 20%"}
execute if score @s tq_qid matches 49 run data merge storage tq:tmp {ans:"A - 800 blocks",ansfull:"A - 800 blocks"}
execute if score @s tq_qid matches 50 run data merge storage tq:tmp {ans:"B - 3",ansfull:"B - 3"}
execute if score @s tq_qid matches 51 run data merge storage tq:tmp {ans:"C - 6 seconds",ansfull:"C - 6 seconds"}
execute if score @s tq_qid matches 52 run data merge storage tq:tmp {ans:"A - Opening a chest they can see",ansfull:"A - Opening a chest they can see"}
execute if score @s tq_qid matches 53 run data merge storage tq:tmp {ans:"D - Weaponsmith",ansfull:"D - Weaponsmith"}
execute if score @s tq_qid matches 54 run data merge storage tq:tmp {ans:"B - Flint and steel",ansfull:"B - Flint and steel"}
execute if score @s tq_qid matches 55 run data merge storage tq:tmp {ans:"C - 10 crystals, 2 caged",ansfull:"C - 10 crystals, 2 caged"}
execute if score @s tq_qid matches 56 run data merge storage tq:tmp {ans:"D - When you enter the exit porta...",ansfull:"D - When you enter the exit portal after the dragon dies"}
execute if score @s tq_qid matches 57 run data merge storage tq:tmp {ans:"D - Better pearl bartering and no...",ansfull:"D - Better pearl bartering and no piglin brutes"}
execute if score @s tq_qid matches 58 run data merge storage tq:tmp {ans:"A - Warped forest",ansfull:"A - Warped forest"}
execute if score @s tq_qid matches 59 run data merge storage tq:tmp {ans:"B - A random seed filtered to gua...",ansfull:"B - A random seed filtered to guarantee good traits"}
execute if score @s tq_qid matches 60 run data merge storage tq:tmp {ans:"A - F3 + G",ansfull:"A - F3 + G"}
execute if score @s tq_qid matches 61 run data merge storage tq:tmp {ans:"B - Y=319",ansfull:"B - Y=319"}
execute if score @s tq_qid matches 62 run data merge storage tq:tmp {ans:"C - Y=31",ansfull:"C - Y=31"}
execute if score @s tq_qid matches 63 run data merge storage tq:tmp {ans:"A - Basalt Deltas",ansfull:"A - Basalt Deltas"}
execute if score @s tq_qid matches 64 run data merge storage tq:tmp {ans:"D - Crimson Forest",ansfull:"D - Crimson Forest"}
execute if score @s tq_qid matches 65 run data merge storage tq:tmp {ans:"B - Meadow",ansfull:"B - Meadow"}
execute if score @s tq_qid matches 66 run data merge storage tq:tmp {ans:"C - End Highlands",ansfull:"C - End Highlands"}
execute if score @s tq_qid matches 67 run data merge storage tq:tmp {ans:"D - 1 in 10",ansfull:"D - 1 in 10"}
execute if score @s tq_qid matches 68 run data merge storage tq:tmp {ans:"A - They never spawn naturally, e...",ansfull:"A - They never spawn naturally, even in caves below"}
execute if score @s tq_qid matches 69 run data merge storage tq:tmp {ans:"C - Warped Forest",ansfull:"C - Warped Forest"}
execute if score @s tq_qid matches 70 run data merge storage tq:tmp {ans:"D - 9",ansfull:"D - 9"}
execute if score @s tq_qid matches 71 run data merge storage tq:tmp {ans:"C - About half",ansfull:"C - About half"}
execute if score @s tq_qid matches 72 run data merge storage tq:tmp {ans:"B - 29,999,984 blocks",ansfull:"B - 29,999,984 blocks"}
execute if score @s tq_qid matches 73 run data merge storage tq:tmp {ans:"A - Y=192",ansfull:"A - Y=192"}
execute if score @s tq_qid matches 74 run data merge storage tq:tmp {ans:"A - One witch and one black cat",ansfull:"A - One witch and one black cat"}
execute if score @s tq_qid matches 75 run data merge storage tq:tmp {ans:"B - Y=8 down to Y=0",ansfull:"B - Y=8 down to Y=0"}
execute if score @s tq_qid matches 76 run data merge storage tq:tmp {ans:"B - W1ndLeaf",ansfull:"B - W1ndLeaf"}
execute if score @s tq_qid matches 77 run data merge storage tq:tmp {ans:"B - 9",ansfull:"B - 9"}
execute if score @s tq_qid matches 78 run data merge storage tq:tmp {ans:"D - Iron Pickaxe",ansfull:"D - Iron Pickaxe"}
execute if score @s tq_qid matches 79 run data merge storage tq:tmp {ans:"C - 20",ansfull:"C - 20"}
execute if score @s tq_qid matches 80 run data merge storage tq:tmp {ans:"A - Ancient Debris",ansfull:"A - Ancient Debris"}
execute if score @s tq_qid matches 81 run data merge storage tq:tmp {ans:"B - Slime Block",ansfull:"B - Slime Block"}
execute if score @s tq_qid matches 82 run data merge storage tq:tmp {ans:"D - 20",ansfull:"D - 20"}
execute if score @s tq_qid matches 83 run data merge storage tq:tmp {ans:"B - Slowness IV and Resistance III",ansfull:"B - Slowness IV and Resistance III"}
execute if score @s tq_qid matches 84 run data merge storage tq:tmp {ans:"A - Golden",ansfull:"A - Golden"}
execute if score @s tq_qid matches 85 run data merge storage tq:tmp {ans:"C - 12%",ansfull:"C - 12%"}
execute if score @s tq_qid matches 86 run data merge storage tq:tmp {ans:"B - 8",ansfull:"B - 8"}
execute if score @s tq_qid matches 87 run data merge storage tq:tmp {ans:"D - Reinforced Deepslate",ansfull:"D - Reinforced Deepslate"}
execute if score @s tq_qid matches 88 run data merge storage tq:tmp {ans:"D - 16",ansfull:"D - 16"}
execute if score @s tq_qid matches 89 run data merge storage tq:tmp {ans:"B - 2",ansfull:"B - 2"}
execute if score @s tq_qid matches 90 run data merge storage tq:tmp {ans:"A - Glazed Terracotta",ansfull:"A - Glazed Terracotta"}
execute if score @s tq_qid matches 91 run data merge storage tq:tmp {ans:"C - 4 blocks",ansfull:"C - 4 blocks"}
execute if score @s tq_qid matches 92 run data merge storage tq:tmp {ans:"C - 8 times",ansfull:"C - 8 times"}
execute if score @s tq_qid matches 93 run data merge storage tq:tmp {ans:"A - A random 10 to 30 game ticks",ansfull:"A - A random 10 to 30 game ticks"}
execute if score @s tq_qid matches 94 run data merge storage tq:tmp {ans:"B - 8 game ticks",ansfull:"B - 8 game ticks"}
execute if score @s tq_qid matches 95 run data merge storage tq:tmp {ans:"D - Pocket Edition 0.15.0",ansfull:"D - Pocket Edition 0.15.0"}
execute if score @s tq_qid matches 96 run data merge storage tq:tmp {ans:"A - Spawning a wither (power 7)",ansfull:"A - Spawning a wither (power 7)"}
execute if score @s tq_qid matches 97 run data merge storage tq:tmp {ans:"C - It is primed by an update mid...",ansfull:"C - It is primed by an update mid-push, so the block itself is kept"}
execute if score @s tq_qid matches 98 run data merge storage tq:tmp {ans:"B - 300 game ticks (15 s)",ansfull:"B - 300 game ticks (15 s)"}
execute if score @s tq_qid matches 99 run data merge storage tq:tmp {ans:"D - 9",ansfull:"D - 9"}
execute if score @s tq_qid matches 100 run data merge storage tq:tmp {ans:"C - 36",ansfull:"C - 36"}
execute if score @s tq_qid matches 101 run data merge storage tq:tmp {ans:"A - Bedrock, only in the End",ansfull:"A - Bedrock, only in the End"}
execute if score @s tq_qid matches 102 run data merge storage tq:tmp {ans:"B - 23w46a",ansfull:"B - 23w46a"}
execute if score @s tq_qid matches 103 run data merge storage tq:tmp {ans:"D - 20w12a",ansfull:"D - 20w12a"}
execute if score @s tq_qid matches 104 run data merge storage tq:tmp {ans:"C - RubyDung",ansfull:"C - RubyDung"}
execute if score @s tq_qid matches 105 run data merge storage tq:tmp {ans:"A - Beta 1.6.6",ansfull:"A - Beta 1.6.6"}
execute if score @s tq_qid matches 106 run data merge storage tq:tmp {ans:"B - 1 in 800",ansfull:"B - 1 in 800"}
execute if score @s tq_qid matches 107 run data merge storage tq:tmp {ans:"C - 5.5%",ansfull:"C - 5.5%"}
execute if score @s tq_qid matches 108 run data merge storage tq:tmp {ans:"A - 0.1%",ansfull:"A - 0.1%"}
execute if score @s tq_qid matches 109 run data merge storage tq:tmp {ans:"B - Instant Damage from a player'...",ansfull:"B - Instant Damage from a player's potion"}
execute if score @s tq_qid matches 110 run data merge storage tq:tmp {ans:"D - The Resistance effect",ansfull:"D - The Resistance effect"}
execute if score @s tq_qid matches 111 run data merge storage tq:tmp {ans:"B - 25 ticks",ansfull:"B - 25 ticks"}
execute if score @s tq_qid matches 112 run data merge storage tq:tmp {ans:"B - 5",ansfull:"B - 5"}
execute if score @s tq_qid matches 113 run data merge storage tq:tmp {ans:"C - 20 to 34 blocks",ansfull:"C - 20 to 34 blocks"}
execute if score @s tq_qid matches 114 run data merge storage tq:tmp {ans:"B - 289",ansfull:"B - 289"}
execute if score @s tq_qid matches 115 run data merge storage tq:tmp {ans:"D - 11.5%",ansfull:"D - 11.5%"}
execute if score @s tq_qid matches 116 run data merge storage tq:tmp {ans:"A - Y=51 to Y=69",ansfull:"A - Y=51 to Y=69"}
execute if score @s tq_qid matches 117 run data merge storage tq:tmp {ans:"C - 75%",ansfull:"C - 75%"}
execute if score @s tq_qid matches 118 run data merge storage tq:tmp {ans:"A - 64%",ansfull:"A - 64%"}
execute if score @s tq_qid matches 119 run data merge storage tq:tmp {ans:"C - Blindness",ansfull:"C - Blindness"}
execute if score @s tq_qid matches 120 run data merge storage tq:tmp {ans:"D - Drowned",ansfull:"D - Drowned"}
execute if score @s tq_qid matches 121 run data merge storage tq:tmp {ans:"A - 12 or higher",ansfull:"A - 12 or higher"}
execute if score @s tq_qid matches 122 run data merge storage tq:tmp {ans:"B - 20/423 (~4.7%), 4-8 pearls",ansfull:"B - 20/423 (~4.7%), 4-8 pearls"}
execute if score @s tq_qid matches 123 run data merge storage tq:tmp {ans:"C - 16 blocks",ansfull:"C - 16 blocks"}
execute if score @s tq_qid matches 124 run data merge storage tq:tmp {ans:"A - Skeleton",ansfull:"A - Skeleton"}
execute if score @s tq_qid matches 125 run data merge storage tq:tmp {ans:"A - 2",ansfull:"A - 2"}
execute if score @s tq_qid matches 126 run data merge storage tq:tmp {ans:"D - 28%",ansfull:"D - 28%"}
execute if score @s tq_qid matches 127 run data merge storage tq:tmp {ans:"C - The chunk's (0, 0) corner",ansfull:"C - The chunk's (0, 0) corner"}
execute if score @s tq_qid matches 128 run data merge storage tq:tmp {ans:"B - Glowstone dust and magma cream",ansfull:"B - Glowstone dust and magma cream"}
execute if score @s tq_qid matches 129 run data merge storage tq:tmp {ans:"C - Furnace",ansfull:"C - Furnace"}
execute if score @s tq_qid matches 130 run data merge storage tq:tmp {ans:"A - 1 in (3 + crystals alive)",ansfull:"A - 1 in (3 + crystals alive)"}
execute if score @s tq_qid matches 131 run data merge storage tq:tmp {ans:"D - 50 HP (25 hearts)",ansfull:"D - 50 HP (25 hearts)"}
execute if score @s tq_qid matches 132 run data merge storage tq:tmp {ans:"C - The second and third shortest...",ansfull:"C - The second and third shortest pillars"}
execute if score @s tq_qid matches 133 run data merge storage tq:tmp {ans:"D - Treasure Room",ansfull:"D - Treasure Room"}
execute if score @s tq_qid matches 134 run data merge storage tq:tmp {ans:"A - Bridge chest",ansfull:"A - Bridge chest"}
execute if score @s tq_qid matches 135 run data merge storage tq:tmp {ans:"D - 10%",ansfull:"D - 10%"}
execute if score @s tq_qid matches 136 run data merge storage tq:tmp {ans:"B - 40%",ansfull:"B - 40%"}
execute if score @s tq_qid matches 137 run data merge storage tq:tmp {ans:"B - 1 in 64",ansfull:"B - 1 in 64"}
execute if score @s tq_qid matches 138 run data merge storage tq:tmp {ans:"C - 1 in 1000",ansfull:"C - 1 in 1000"}
execute if score @s tq_qid matches 139 run data merge storage tq:tmp {ans:"A - Y=-51",ansfull:"A - Y=-51"}
execute if score @s tq_qid matches 140 run data merge storage tq:tmp {ans:"B - Y=-40 and Y=-20",ansfull:"B - Y=-40 and Y=-20"}
execute if score @s tq_qid matches 141 run data merge storage tq:tmp {ans:"C - (9, 9)",ansfull:"C - (9, 9)"}
execute if score @s tq_qid matches 142 run data merge storage tq:tmp {ans:"D - 0.4%",ansfull:"D - 0.4%"}
execute if score @s tq_qid matches 143 run data merge storage tq:tmp {ans:"D - 96 blocks out, Y=75",ansfull:"D - 96 blocks out, Y=75"}
execute if score @s tq_qid matches 144 run data merge storage tq:tmp {ans:"A - 1024 blocks",ansfull:"A - 1024 blocks"}
execute if score @s tq_qid matches 145 run data merge storage tq:tmp {ans:"C - Y=232",ansfull:"C - Y=232"}
execute if score @s tq_qid matches 146 run data merge storage tq:tmp {ans:"A - 12,550,824",ansfull:"A - 12,550,824"}
execute if score @s tq_qid matches 147 run data merge storage tq:tmp {ans:"B - 32-bit",ansfull:"B - 32-bit"}
execute if score @s tq_qid matches 148 run data merge storage tq:tmp {ans:"C - 1/24, from Y=-58 to Y=30",ansfull:"C - 1/24, from Y=-58 to Y=30"}
execute if score @s tq_qid matches 149 run data merge storage tq:tmp {ans:"C - 19x19 to 3x3; removed in 1.21.9",ansfull:"C - 19x19 to 3x3; removed in 1.21.9"}
execute if score @s tq_qid matches 150 run data merge storage tq:tmp {ans:"B - 70%",ansfull:"B - 70%"}
execute if score @s tq_qid matches 151 run data merge storage tq:tmp {ans:"D - The second and third shortest...",ansfull:"D - The second and third shortest (Y=79 and Y=82)"}
execute if score @s tq_qid matches 152 run data merge storage tq:tmp {ans:"B - W1ndLeaf",ansfull:"B - W1ndLeaf"}
