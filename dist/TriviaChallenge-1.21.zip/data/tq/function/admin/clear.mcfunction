effect clear @s
function tq:timers/clear_all
function tq:freeze/stop_silent
tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"cleared.","color":"gold"}]}
