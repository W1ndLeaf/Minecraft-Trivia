function tq:reward/random
