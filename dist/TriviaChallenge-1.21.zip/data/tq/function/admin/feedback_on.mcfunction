gamerule sendCommandFeedback true
gamerule logAdminCommands true
scoreboard players set #fb_set tq_cfg 2
tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"command feedback is back on (the Triggered [...] lines will show again).","color":"gold"}]}
