function tq:all_r_on
function tq:all_p_on
