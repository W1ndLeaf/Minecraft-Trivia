function tq:reset_n
function tq:reset_h
