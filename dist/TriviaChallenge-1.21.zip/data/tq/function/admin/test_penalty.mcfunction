data remove storage tq:tmp ans
data remove storage tq:tmp ansfull
title @s subtitle ""
function tq:penalty/random
