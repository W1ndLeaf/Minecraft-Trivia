$scoreboard players display name Nxt tq_score {"text":"Next question: $(m) min","color":"aqua"}
$scoreboard players display name Cor tq_score {"text":"Correct: $(c)","color":"green"}
$scoreboard players display name Wrg tq_score {"text":"Wrong: $(w)","color":"red"}
