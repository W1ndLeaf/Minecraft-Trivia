scoreboard objectives add tq_timer dummy
scoreboard objectives add tq_state dummy
scoreboard objectives add tq_qid dummy
scoreboard objectives add tq_last dummy
scoreboard objectives add tq_wait dummy
scoreboard objectives add tq_delay dummy
scoreboard objectives add tq_tmp dummy
scoreboard objectives add tq_right dummy
scoreboard objectives add tq_wrong dummy
scoreboard objectives add tq_cfg dummy
scoreboard objectives add tq_key dummy
scoreboard objectives add tq_seen dummy
scoreboard objectives add tq_w dummy
scoreboard objectives add tq_on dummy
scoreboard objectives add tq_t_jump dummy
scoreboard objectives add tq_t_scale dummy
scoreboard objectives add tq_t_reach dummy
scoreboard objectives add tq_t_fall dummy
scoreboard objectives add tq_answer trigger
scoreboard objectives add tq_ask trigger
scoreboard objectives add tq_interval trigger
scoreboard objectives add tq_menu trigger
scoreboard objectives add tq_opts trigger
scoreboard objectives add tq_diff trigger
scoreboard objectives add tq_stats trigger
scoreboard objectives add tq_rl trigger
scoreboard objectives add tq_pl trigger
scoreboard objectives add tq_tr trigger
scoreboard objectives add tq_tp trigger
scoreboard objectives add tq_status trigger
scoreboard objectives add tq_health health
scoreboard objectives add tq_deaths deathCount
scoreboard objectives add tq_leave minecraft.custom:minecraft.leave_game
scoreboard objectives add tq_score dummy {"text":"Trivia Challenge","color":"gold"}
scoreboard objectives modify tq_score numberformat blank
scoreboard players set Nxt tq_score 3
scoreboard players set Cor tq_score 2
scoreboard players set Wrg tq_score 1
scoreboard players display name Nxt tq_score {"text":"Next question: - min","color":"aqua"}
scoreboard players display name Cor tq_score {"text":"Correct: -","color":"green"}
scoreboard players display name Wrg tq_score {"text":"Wrong: -","color":"red"}
execute unless score #sidebar tq_cfg matches 0..1 run scoreboard players set #sidebar tq_cfg 1
execute if score #sidebar tq_cfg matches 1 run scoreboard objectives setdisplay sidebar tq_score
execute unless score #interval_min tq_cfg matches 1.. run scoreboard players set #interval_min tq_cfg 5
execute unless score #interval tq_cfg matches 1.. run scoreboard players set #interval tq_cfg 6000
execute unless score #diff tq_cfg matches 1..2 run scoreboard players set #diff tq_cfg 1
scoreboard players set #1200 tq_cfg 1200
scoreboard players set #two tq_cfg 2
scoreboard players set #five tq_cfg 5
scoreboard players set #eight tq_cfg 8
scoreboard players set #twelve tq_cfg 12
scoreboard players set #clock tq_cfg 0
scoreboard players set #N_min tq_cfg 1
scoreboard players set #N_max tq_cfg 76
scoreboard players set #H_min tq_cfg 77
scoreboard players set #H_max tq_cfg 152
execute unless score #unseen_N tq_cfg matches 0..76 run scoreboard players set #unseen_N tq_cfg 76
execute unless score #unseen_H tq_cfg matches 0..76 run scoreboard players set #unseen_H tq_cfg 76
execute unless score r1 tq_w matches 1.. run scoreboard players set r1 tq_w 64
execute unless score r1 tq_on matches 0..1 run scoreboard players set r1 tq_on 1
execute unless score r2 tq_w matches 1.. run scoreboard players set r2 tq_w 64
execute unless score r2 tq_on matches 0..1 run scoreboard players set r2 tq_on 1
execute unless score r3 tq_w matches 1.. run scoreboard players set r3 tq_w 64
execute unless score r3 tq_on matches 0..1 run scoreboard players set r3 tq_on 1
execute unless score r4 tq_w matches 1.. run scoreboard players set r4 tq_w 64
execute unless score r4 tq_on matches 0..1 run scoreboard players set r4 tq_on 1
execute unless score r5 tq_w matches 1.. run scoreboard players set r5 tq_w 64
execute unless score r5 tq_on matches 0..1 run scoreboard players set r5 tq_on 1
execute unless score r6 tq_w matches 1.. run scoreboard players set r6 tq_w 64
execute unless score r6 tq_on matches 0..1 run scoreboard players set r6 tq_on 1
execute unless score r7 tq_w matches 1.. run scoreboard players set r7 tq_w 64
execute unless score r7 tq_on matches 0..1 run scoreboard players set r7 tq_on 1
execute unless score r8 tq_w matches 1.. run scoreboard players set r8 tq_w 64
execute unless score r8 tq_on matches 0..1 run scoreboard players set r8 tq_on 1
execute unless score r9 tq_w matches 1.. run scoreboard players set r9 tq_w 64
execute unless score r9 tq_on matches 0..1 run scoreboard players set r9 tq_on 1
execute unless score r10 tq_w matches 1.. run scoreboard players set r10 tq_w 64
execute unless score r10 tq_on matches 0..1 run scoreboard players set r10 tq_on 1
execute unless score r11 tq_w matches 1.. run scoreboard players set r11 tq_w 64
execute unless score r11 tq_on matches 0..1 run scoreboard players set r11 tq_on 1
execute unless score r12 tq_w matches 1.. run scoreboard players set r12 tq_w 64
execute unless score r12 tq_on matches 0..1 run scoreboard players set r12 tq_on 1
execute unless score r13 tq_w matches 1.. run scoreboard players set r13 tq_w 64
execute unless score r13 tq_on matches 0..1 run scoreboard players set r13 tq_on 1
execute unless score r14 tq_w matches 1.. run scoreboard players set r14 tq_w 64
execute unless score r14 tq_on matches 0..1 run scoreboard players set r14 tq_on 1
execute unless score r15 tq_w matches 1.. run scoreboard players set r15 tq_w 64
execute unless score r15 tq_on matches 0..1 run scoreboard players set r15 tq_on 1
execute unless score r16 tq_w matches 1.. run scoreboard players set r16 tq_w 64
execute unless score r16 tq_on matches 0..1 run scoreboard players set r16 tq_on 1
execute unless score r17 tq_w matches 1.. run scoreboard players set r17 tq_w 64
execute unless score r17 tq_on matches 0..1 run scoreboard players set r17 tq_on 1
execute unless score r18 tq_w matches 1.. run scoreboard players set r18 tq_w 64
execute unless score r18 tq_on matches 0..1 run scoreboard players set r18 tq_on 1
execute unless score p1 tq_w matches 1.. run scoreboard players set p1 tq_w 64
execute unless score p1 tq_on matches 0..1 run scoreboard players set p1 tq_on 1
execute unless score p2 tq_w matches 1.. run scoreboard players set p2 tq_w 64
execute unless score p2 tq_on matches 0..1 run scoreboard players set p2 tq_on 1
execute unless score p3 tq_w matches 1.. run scoreboard players set p3 tq_w 64
execute unless score p3 tq_on matches 0..1 run scoreboard players set p3 tq_on 1
execute unless score p4 tq_w matches 1.. run scoreboard players set p4 tq_w 64
execute unless score p4 tq_on matches 0..1 run scoreboard players set p4 tq_on 1
execute unless score p5 tq_w matches 1.. run scoreboard players set p5 tq_w 64
execute unless score p5 tq_on matches 0..1 run scoreboard players set p5 tq_on 1
execute unless score p6 tq_w matches 1.. run scoreboard players set p6 tq_w 64
execute unless score p6 tq_on matches 0..1 run scoreboard players set p6 tq_on 1
execute unless score p7 tq_w matches 1.. run scoreboard players set p7 tq_w 64
execute unless score p7 tq_on matches 0..1 run scoreboard players set p7 tq_on 1
execute unless score p8 tq_w matches 1.. run scoreboard players set p8 tq_w 64
execute unless score p8 tq_on matches 0..1 run scoreboard players set p8 tq_on 1
execute unless score p9 tq_w matches 1.. run scoreboard players set p9 tq_w 64
execute unless score p9 tq_on matches 0..1 run scoreboard players set p9 tq_on 1
execute unless score p10 tq_w matches 1.. run scoreboard players set p10 tq_w 64
execute unless score p10 tq_on matches 0..1 run scoreboard players set p10 tq_on 1
execute unless score p11 tq_w matches 1.. run scoreboard players set p11 tq_w 64
execute unless score p11 tq_on matches 0..1 run scoreboard players set p11 tq_on 1
execute unless score p12 tq_w matches 1.. run scoreboard players set p12 tq_w 64
execute unless score p12 tq_on matches 0..1 run scoreboard players set p12 tq_on 1
execute unless score p13 tq_w matches 1.. run scoreboard players set p13 tq_w 64
execute unless score p13 tq_on matches 0..1 run scoreboard players set p13 tq_on 1
execute unless score p14 tq_w matches 1.. run scoreboard players set p14 tq_w 64
execute unless score p14 tq_on matches 0..1 run scoreboard players set p14 tq_on 1
execute unless score p15 tq_w matches 1.. run scoreboard players set p15 tq_w 64
execute unless score p15 tq_on matches 0..1 run scoreboard players set p15 tq_on 1
execute unless score p16 tq_w matches 1.. run scoreboard players set p16 tq_w 64
execute unless score p16 tq_on matches 0..1 run scoreboard players set p16 tq_on 1
execute unless score p17 tq_w matches 1.. run scoreboard players set p17 tq_w 64
execute unless score p17 tq_on matches 0..1 run scoreboard players set p17 tq_on 1
execute unless score p18 tq_w matches 1.. run scoreboard players set p18 tq_w 64
execute unless score p18 tq_on matches 0..1 run scoreboard players set p18 tq_on 1
execute unless score p19 tq_w matches 1.. run scoreboard players set p19 tq_w 64
execute unless score p19 tq_on matches 0..1 run scoreboard players set p19 tq_on 1
execute unless score p20 tq_w matches 1.. run scoreboard players set p20 tq_w 64
execute unless score p20 tq_on matches 0..1 run scoreboard players set p20 tq_on 1
execute unless score p21 tq_w matches 1.. run scoreboard players set p21 tq_w 64
execute unless score p21 tq_on matches 0..1 run scoreboard players set p21 tq_on 1
execute unless score p22 tq_w matches 1.. run scoreboard players set p22 tq_w 64
execute unless score p22 tq_on matches 0..1 run scoreboard players set p22 tq_on 1
execute unless score p23 tq_w matches 1.. run scoreboard players set p23 tq_w 64
execute unless score p23 tq_on matches 0..1 run scoreboard players set p23 tq_on 1
execute unless score #fb_set tq_cfg matches 1.. run function tq:feedback_off
function tq:freeze/stop_silent
function tq:keys
function tq:enable_triggers
tellraw @a {"text":"[Trivia] ","color":"gold","extra":[{"text":"loaded 152 questions. ","color":"gray"},{"text":"/trigger tq_menu","color":"yellow"},{"text":" = menu, ","color":"gray"},{"text":"/trigger tq_ask","color":"yellow"},{"text":" = a question now.","color":"gray"}]}
