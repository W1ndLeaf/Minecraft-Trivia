scoreboard players add @s tq_wait 1
execute if score @s tq_wait matches 2400.. run function tq:reshow
