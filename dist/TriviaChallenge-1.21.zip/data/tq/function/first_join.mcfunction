tag @s add tq_init
scoreboard players set @s tq_state 0
scoreboard players set @s tq_timer 0
scoreboard players set @s tq_wait 0
scoreboard players set @s tq_leave 0
execute unless score @s tq_right matches 0.. run scoreboard players set @s tq_right 0
execute unless score @s tq_wrong matches 0.. run scoreboard players set @s tq_wrong 0
execute unless data storage tq:spawn x run data modify storage tq:spawn x set from entity @s Pos[0]
execute unless data storage tq:spawn y run data modify storage tq:spawn y set from entity @s Pos[1]
execute unless data storage tq:spawn z run data modify storage tq:spawn z set from entity @s Pos[2]
tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Welcome! ","color":"gray"},{"text":"/trigger tq_menu","color":"yellow"},{"text":" = menu and options, ","color":"gray"},{"text":"/trigger tq_ask","color":"yellow"},{"text":" = a question now.","color":"gray"}]}
