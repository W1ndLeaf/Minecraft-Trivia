scoreboard players remove @s tq_delay 1
execute if score @s tq_delay matches 0 run function tq:ui/menu_show
