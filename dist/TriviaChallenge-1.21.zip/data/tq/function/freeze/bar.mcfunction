title @a actionbar [{"text":"TIME FREEZE  ","color":"aqua","bold":true},{"score":{"name":"#freeze","objective":"tq_cfg"},"color":"aqua"}]
