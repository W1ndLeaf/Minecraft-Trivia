scoreboard players set #freeze tq_cfg 10
execute as @e[type=!player,type=!item,type=!experience_orb,distance=..96] run function tq:freeze/hold
function tq:freeze/bar
