scoreboard players remove #freeze tq_cfg 1
execute if score #freeze tq_cfg matches 1.. run function tq:freeze/bar
execute if score #freeze tq_cfg matches ..0 run function tq:freeze/stop
