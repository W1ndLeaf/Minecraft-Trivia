execute unless data entity @s {NoAI:1b} run tag @s add tq_frozen
execute if entity @s[tag=tq_frozen] run data merge entity @s {NoAI:1b}
