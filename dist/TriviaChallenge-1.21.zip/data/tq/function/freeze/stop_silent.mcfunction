scoreboard players set #freeze tq_cfg 0
execute as @e[tag=tq_frozen] run function tq:freeze/release
