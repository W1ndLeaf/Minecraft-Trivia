data merge entity @s {NoAI:0b}
tag @s remove tq_frozen
