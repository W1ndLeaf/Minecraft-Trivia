title @s actionbar [{"text":"Interval: a question every ","color":"aqua"},{"score":{"name":"#interval_min","objective":"tq_cfg"},"color":"aqua"},{"text":" min","color":"aqua"}]
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"a question every ","color":"gray"},{"score":{"name":"#interval_min","objective":"tq_cfg"},"color":"gray"},{"text":" minute(s).","color":"gray"}]
