scoreboard players operation #tmp tq_cfg = #sidebar tq_cfg
execute if score #tmp tq_cfg matches 0 run scoreboard players set #sidebar tq_cfg 1
execute if score #tmp tq_cfg matches 1 run scoreboard players set #sidebar tq_cfg 0
execute if score #sidebar tq_cfg matches 1 run scoreboard objectives setdisplay sidebar tq_score
execute if score #sidebar tq_cfg matches 0 run scoreboard objectives setdisplay sidebar
execute if score #sidebar tq_cfg matches 1 run function tq:sidebar
execute if score #sidebar tq_cfg matches 1 run title @s actionbar {"text":"Score display: ON","color":"green"}
execute if score #sidebar tq_cfg matches 0 run title @s actionbar {"text":"Score display: OFF","color":"red"}
execute if score #sidebar tq_cfg matches 1 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"score display ON.","color":"green"}]}
execute if score #sidebar tq_cfg matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"score display off.","color":"gray"}]}
