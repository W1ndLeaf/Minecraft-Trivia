scoreboard players set @s tq_last 1
scoreboard players add @s tq_right 1
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2
function tq:reward/random
