title @s times 10 70 20
title @s subtitle {"text":"hunger and saturation restored","color":"white"}
effect give @s minecraft:saturation 1 10 true
title @s title {"text":"Full belly","color":"green"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Full belly - hunger and saturation restored","color":"green"}]
