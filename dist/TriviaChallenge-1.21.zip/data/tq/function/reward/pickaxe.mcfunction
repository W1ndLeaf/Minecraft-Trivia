title @s times 10 70 20
title @s subtitle {"text":"check your inventory","color":"white"}
give @s minecraft:iron_pickaxe
title @s title {"text":"Iron pickaxe","color":"green"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Iron pickaxe - check your inventory","color":"green"}]
