title @s times 10 70 20
title @s subtitle {"text":"10 s - every mob stops, you do not","color":"white"}
function tq:freeze/start
title @s title {"text":"TIME FREEZE","color":"aqua"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Time freeze - 10 s - every mob stops, you do not","color":"green"}]
