title @s times 10 70 20
title @s subtitle {"text":"3 minutes","color":"white"}
effect give @s minecraft:fire_resistance 180 0 true
title @s title {"text":"Fire Resistance","color":"gold"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Fire Res 3 min - 3 minutes","color":"green"}]
