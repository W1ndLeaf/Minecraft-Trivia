title @s times 10 70 20
title @s subtitle {"text":"check your inventory","color":"white"}
give @s minecraft:cobblestone 64
title @s title {"text":"64 Cobblestone","color":"green"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: 64 Cobblestone - check your inventory","color":"green"}]
