title @s times 10 70 20
title @s subtitle {"text":"check your inventory","color":"white"}
give @s minecraft:bow
give @s minecraft:arrow 8
title @s title {"text":"Bow + 8 arrows","color":"green"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Bow + arrows - check your inventory","color":"green"}]
