title @s times 10 70 20
title @s subtitle {"text":"Regeneration II for 15 seconds","color":"white"}
effect give @s minecraft:regeneration 15 1 true
title @s title {"text":"Second wind","color":"green"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Second wind - Regeneration II for 15 seconds","color":"green"}]
