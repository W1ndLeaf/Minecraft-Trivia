title @s times 10 70 20
title @s subtitle {"text":"check your inventory","color":"white"}
loot give @s loot tq:useful_item
title @s title {"text":"Useful item","color":"green"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Useful item - check your inventory","color":"green"}]
