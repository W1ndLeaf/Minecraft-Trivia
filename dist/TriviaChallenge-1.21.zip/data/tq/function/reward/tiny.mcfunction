title @s times 10 70 20
title @s subtitle {"text":"half size for 3 minutes","color":"white"}
attribute @s minecraft:generic.scale base set 0.5
scoreboard players set @s tq_t_scale 180
title @s title {"text":"TINY","color":"aqua"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Tiny - half size for 3 minutes","color":"green"}]
