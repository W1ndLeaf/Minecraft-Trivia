title @s times 10 70 20
title @s subtitle {"text":"water bucket + boat","color":"white"}
give @s minecraft:water_bucket
give @s minecraft:oak_boat
title @s title {"text":"Classic tools","color":"green"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Classic tools - water bucket + boat","color":"green"}]
