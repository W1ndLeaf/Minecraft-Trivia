title @s times 10 70 20
title @s subtitle {"text":"your respawn point is now here","color":"white"}
spawnpoint @s ~ ~ ~
title @s title {"text":"Safe spawn","color":"green"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Safe spawn - your respawn point is now here","color":"green"}]
