title @s times 10 70 20
title @s subtitle {"text":"3 minutes","color":"white"}
effect give @s minecraft:speed 180 0 true
title @s title {"text":"Speed I","color":"gold"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Speed 3 min - 3 minutes","color":"green"}]
