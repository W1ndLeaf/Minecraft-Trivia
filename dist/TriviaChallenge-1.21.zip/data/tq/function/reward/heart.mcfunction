title @s times 10 70 20
title @s subtitle {"text":"max health up, permanent","color":"white"}
execute store result score #h tq_cfg run attribute @s minecraft:generic.max_health base get
scoreboard players add #h tq_cfg 2
execute if score #h tq_cfg matches 41.. run scoreboard players set #h tq_cfg 40
function tq:reward/heart_set
title @s title {"text":"+1 heart","color":"gold"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: +1 heart - max health up, permanent","color":"green"}]
