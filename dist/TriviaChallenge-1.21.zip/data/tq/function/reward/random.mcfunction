scoreboard players set #sum tq_cfg 0
execute if score r1 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r1 tq_w
execute if score r2 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r2 tq_w
execute if score r3 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r3 tq_w
execute if score r4 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r4 tq_w
execute if score r5 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r5 tq_w
execute if score r6 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r6 tq_w
execute if score r7 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r7 tq_w
execute if score r8 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r8 tq_w
execute if score r9 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r9 tq_w
execute if score r10 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r10 tq_w
execute if score r11 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r11 tq_w
execute if score r12 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r12 tq_w
execute if score r13 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r13 tq_w
execute if score r14 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r14 tq_w
execute if score r15 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r15 tq_w
execute if score r16 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r16 tq_w
execute if score r17 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r17 tq_w
execute if score r18 tq_on matches 1 run scoreboard players operation #sum tq_cfg += r18 tq_w
execute if score #sum tq_cfg matches ..0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"every reward is switched off - nothing happens.","color":"yellow"}]}
execute if score #sum tq_cfg matches 1.. run function tq:reward/roll
