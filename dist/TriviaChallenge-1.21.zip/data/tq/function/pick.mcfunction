execute if score #diff tq_cfg matches 1 if score #unseen_N tq_cfg matches ..0 run function tq:reset_n
execute if score #diff tq_cfg matches 2 if score #unseen_H tq_cfg matches ..0 run function tq:reset_h
execute if score #diff tq_cfg matches 1 run scoreboard players operation #unseen tq_cfg = #unseen_N tq_cfg
execute if score #diff tq_cfg matches 2 run scoreboard players operation #unseen tq_cfg = #unseen_H tq_cfg
function tq:rng
scoreboard players operation #k tq_cfg = #rnd tq_cfg
scoreboard players operation #k tq_cfg %= #unseen tq_cfg
scoreboard players add #k tq_cfg 1
scoreboard players set #done tq_cfg 0
execute if score #diff tq_cfg matches 1 run function tq:pick_walk_n
execute if score #diff tq_cfg matches 2 run function tq:pick_walk_h
execute if score #done tq_cfg matches 0 if score #diff tq_cfg matches 1 run scoreboard players operation @s tq_qid = #N_min tq_cfg
execute if score #done tq_cfg matches 0 if score #diff tq_cfg matches 2 run scoreboard players operation @s tq_qid = #H_min tq_cfg
function tq:pick_mark
execute if score #diff tq_cfg matches 1 run scoreboard players remove #unseen_N tq_cfg 1
execute if score #diff tq_cfg matches 2 run scoreboard players remove #unseen_H tq_cfg 1
