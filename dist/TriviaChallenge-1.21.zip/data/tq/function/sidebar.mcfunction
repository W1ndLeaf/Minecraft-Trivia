scoreboard players operation #m tq_cfg = #interval tq_cfg
scoreboard players operation #m tq_cfg -= @s tq_timer
scoreboard players operation #m tq_cfg /= #1200 tq_cfg
scoreboard players add #m tq_cfg 1
execute unless score @s tq_state matches 0 run scoreboard players set #m tq_cfg 0
execute store result storage tq:tmp c int 1 run scoreboard players get @s tq_right
execute store result storage tq:tmp w int 1 run scoreboard players get @s tq_wrong
execute store result storage tq:tmp m int 1 run scoreboard players get #m tq_cfg
function tq:sidebar_names with storage tq:tmp
