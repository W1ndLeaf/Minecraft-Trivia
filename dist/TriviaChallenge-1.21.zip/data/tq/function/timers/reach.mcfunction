scoreboard players remove @s tq_t_reach 1
execute if score @s tq_t_reach matches ..0 run attribute @s minecraft:player.block_interaction_range base set 4.5
execute if score @s tq_t_reach matches ..0 run scoreboard players reset @s tq_t_reach
