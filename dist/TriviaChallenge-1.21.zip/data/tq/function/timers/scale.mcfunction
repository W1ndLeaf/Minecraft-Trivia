scoreboard players remove @s tq_t_scale 1
execute if score @s tq_t_scale matches ..0 run attribute @s minecraft:generic.scale base set 1
execute if score @s tq_t_scale matches ..0 run scoreboard players reset @s tq_t_scale
