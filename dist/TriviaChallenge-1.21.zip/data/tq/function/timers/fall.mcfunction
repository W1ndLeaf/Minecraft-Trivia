scoreboard players remove @s tq_t_fall 1
execute if score @s tq_t_fall matches ..0 run attribute @s minecraft:generic.fall_damage_multiplier base set 1
execute if score @s tq_t_fall matches ..0 run scoreboard players reset @s tq_t_fall
