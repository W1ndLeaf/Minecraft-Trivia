scoreboard players operation #interval_min tq_cfg = @s tq_interval
scoreboard players set @s tq_interval 0
scoreboard players enable @s tq_interval
function tq:set_interval
