scoreboard players set @s tq_menu 0
scoreboard players enable @s tq_menu
function tq:ui/menu_show
