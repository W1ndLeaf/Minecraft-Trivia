scoreboard players set @s tq_stats 0
scoreboard players enable @s tq_stats
function tq:toggle_stats
