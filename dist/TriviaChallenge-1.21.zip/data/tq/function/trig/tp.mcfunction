scoreboard players operation #tmp tq_cfg = @s tq_tp
scoreboard players set @s tq_tp 0
scoreboard players enable @s tq_tp
execute if score #tmp tq_cfg matches 1 run function tq:tog/p1
execute if score #tmp tq_cfg matches 2 run function tq:tog/p2
execute if score #tmp tq_cfg matches 3 run function tq:tog/p3
execute if score #tmp tq_cfg matches 4 run function tq:tog/p4
execute if score #tmp tq_cfg matches 5 run function tq:tog/p5
execute if score #tmp tq_cfg matches 6 run function tq:tog/p6
execute if score #tmp tq_cfg matches 7 run function tq:tog/p7
execute if score #tmp tq_cfg matches 8 run function tq:tog/p8
execute if score #tmp tq_cfg matches 9 run function tq:tog/p9
execute if score #tmp tq_cfg matches 10 run function tq:tog/p10
execute if score #tmp tq_cfg matches 11 run function tq:tog/p11
execute if score #tmp tq_cfg matches 12 run function tq:tog/p12
execute if score #tmp tq_cfg matches 13 run function tq:tog/p13
execute if score #tmp tq_cfg matches 14 run function tq:tog/p14
execute if score #tmp tq_cfg matches 15 run function tq:tog/p15
execute if score #tmp tq_cfg matches 16 run function tq:tog/p16
execute if score #tmp tq_cfg matches 17 run function tq:tog/p17
execute if score #tmp tq_cfg matches 18 run function tq:tog/p18
execute if score #tmp tq_cfg matches 19 run function tq:tog/p19
execute if score #tmp tq_cfg matches 20 run function tq:tog/p20
execute if score #tmp tq_cfg matches 21 run function tq:tog/p21
execute if score #tmp tq_cfg matches 22 run function tq:tog/p22
execute if score #tmp tq_cfg matches 23 run function tq:tog/p23
execute if score #tmp tq_cfg matches 100 run function tq:all_p_on
execute if score #tmp tq_cfg matches 101 run function tq:all_p_off
