scoreboard players operation #tmp tq_cfg = @s tq_tr
scoreboard players set @s tq_tr 0
scoreboard players enable @s tq_tr
execute if score #tmp tq_cfg matches 1 run function tq:tog/r1
execute if score #tmp tq_cfg matches 2 run function tq:tog/r2
execute if score #tmp tq_cfg matches 3 run function tq:tog/r3
execute if score #tmp tq_cfg matches 4 run function tq:tog/r4
execute if score #tmp tq_cfg matches 5 run function tq:tog/r5
execute if score #tmp tq_cfg matches 6 run function tq:tog/r6
execute if score #tmp tq_cfg matches 7 run function tq:tog/r7
execute if score #tmp tq_cfg matches 8 run function tq:tog/r8
execute if score #tmp tq_cfg matches 9 run function tq:tog/r9
execute if score #tmp tq_cfg matches 10 run function tq:tog/r10
execute if score #tmp tq_cfg matches 11 run function tq:tog/r11
execute if score #tmp tq_cfg matches 12 run function tq:tog/r12
execute if score #tmp tq_cfg matches 13 run function tq:tog/r13
execute if score #tmp tq_cfg matches 14 run function tq:tog/r14
execute if score #tmp tq_cfg matches 15 run function tq:tog/r15
execute if score #tmp tq_cfg matches 16 run function tq:tog/r16
execute if score #tmp tq_cfg matches 17 run function tq:tog/r17
execute if score #tmp tq_cfg matches 18 run function tq:tog/r18
execute if score #tmp tq_cfg matches 100 run function tq:all_r_on
execute if score #tmp tq_cfg matches 101 run function tq:all_r_off
