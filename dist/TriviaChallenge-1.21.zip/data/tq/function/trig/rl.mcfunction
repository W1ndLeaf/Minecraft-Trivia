scoreboard players set @s tq_rl 0
scoreboard players enable @s tq_rl
function tq:ui/rewards_show
