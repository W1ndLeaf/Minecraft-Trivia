scoreboard players set @s tq_pl 0
scoreboard players enable @s tq_pl
function tq:ui/punishments_show
