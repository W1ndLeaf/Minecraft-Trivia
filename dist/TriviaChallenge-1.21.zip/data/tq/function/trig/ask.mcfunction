scoreboard players set @s tq_ask 0
scoreboard players enable @s tq_ask
execute if score @s tq_state matches 0 run function tq:ask
execute unless score @s tq_state matches 0 run function tq:reshow
