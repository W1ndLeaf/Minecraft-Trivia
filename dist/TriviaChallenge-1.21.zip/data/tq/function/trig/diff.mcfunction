scoreboard players operation #tmp tq_cfg = @s tq_diff
scoreboard players set @s tq_diff 0
scoreboard players enable @s tq_diff
function tq:set_diff
