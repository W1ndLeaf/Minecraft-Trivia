scoreboard players set @s tq_opts 0
scoreboard players enable @s tq_opts
function tq:ui/options_show
