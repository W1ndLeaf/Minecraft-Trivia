scoreboard players operation #f tq_cfg = p1 tq_on
execute if score #f tq_cfg matches 1 run scoreboard players set p1 tq_on 0
execute if score #f tq_cfg matches 0 run scoreboard players set p1 tq_on 1
execute if score p1 tq_on matches 1 run title @s actionbar {"text":"Punishment: Grounded is ON","color":"green"}
execute if score p1 tq_on matches 0 run title @s actionbar {"text":"Punishment: Grounded is OFF","color":"red"}
execute if score p1 tq_on matches 1 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Punishment Grounded: ON","color":"green"}]}
execute if score p1 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Punishment Grounded: OFF","color":"red"}]}
