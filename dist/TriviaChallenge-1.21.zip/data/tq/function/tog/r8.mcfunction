scoreboard players operation #f tq_cfg = r8 tq_on
execute if score #f tq_cfg matches 1 run scoreboard players set r8 tq_on 0
execute if score #f tq_cfg matches 0 run scoreboard players set r8 tq_on 1
execute if score r8 tq_on matches 1 run title @s actionbar {"text":"Reward: 64 Cobblestone is ON","color":"green"}
execute if score r8 tq_on matches 0 run title @s actionbar {"text":"Reward: 64 Cobblestone is OFF","color":"red"}
execute if score r8 tq_on matches 1 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Reward 64 Cobblestone: ON","color":"green"}]}
execute if score r8 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Reward 64 Cobblestone: OFF","color":"red"}]}
