scoreboard players operation #f tq_cfg = r11 tq_on
execute if score #f tq_cfg matches 1 run scoreboard players set r11 tq_on 0
execute if score #f tq_cfg matches 0 run scoreboard players set r11 tq_on 1
execute if score r11 tq_on matches 1 run title @s actionbar {"text":"Reward: Time freeze is ON","color":"green"}
execute if score r11 tq_on matches 0 run title @s actionbar {"text":"Reward: Time freeze is OFF","color":"red"}
execute if score r11 tq_on matches 1 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Reward Time freeze: ON","color":"green"}]}
execute if score r11 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Reward Time freeze: OFF","color":"red"}]}
