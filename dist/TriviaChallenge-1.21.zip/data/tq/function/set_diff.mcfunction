execute if score #tmp tq_cfg matches 2.. run scoreboard players set #diff tq_cfg 2
execute if score #tmp tq_cfg matches ..1 run scoreboard players set #diff tq_cfg 1
execute if score #diff tq_cfg matches 1 run title @s actionbar {"text":"Difficulty: NORMAL","color":"green"}
execute if score #diff tq_cfg matches 2 run title @s actionbar {"text":"Difficulty: HARD","color":"red"}
execute if score #diff tq_cfg matches 1 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"difficulty: NORMAL.","color":"green"}]}
execute if score #diff tq_cfg matches 2 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"difficulty: HARD.","color":"red"}]}
