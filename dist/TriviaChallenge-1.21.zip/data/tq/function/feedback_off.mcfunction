gamerule sendCommandFeedback false
gamerule logAdminCommands false
scoreboard players set #fb_set tq_cfg 1
