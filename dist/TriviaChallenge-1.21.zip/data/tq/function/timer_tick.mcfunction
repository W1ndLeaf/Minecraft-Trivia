scoreboard players add @s tq_timer 1
execute if score @s tq_timer >= #interval tq_cfg run function tq:ask
