title @s times 10 70 20
function tq:penalty/lost_go
title @s title {"text":"LOST","color":"dark_red"}
title @s actionbar {"text":"300 blocks away","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Lost - 300 blocks away.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
