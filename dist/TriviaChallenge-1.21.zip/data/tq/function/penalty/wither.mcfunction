title @s times 10 70 20
playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 1 1
summon minecraft:wither ~3 ~ ~3
title @s title {"text":"THE WITHER","color":"dark_red"}
title @s actionbar {"text":"it is right behind you","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Wither - it is right behind you.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
