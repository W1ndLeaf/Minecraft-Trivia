playsound minecraft:entity.item.pickup master @s ~ ~ ~ 1 0.5
execute if data entity @s Inventory[{Slot:0b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:0b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:0b}].id
execute if data entity @s Inventory[{Slot:0b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:0b}].count
execute if data entity @s Inventory[{Slot:0b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:0b}].components
execute if data entity @s Inventory[{Slot:0b}] run item replace entity @s hotbar.0 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:1b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.25d,0.35d,0.25d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:1b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:1b}].id
execute if data entity @s Inventory[{Slot:1b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:1b}].count
execute if data entity @s Inventory[{Slot:1b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:1b}].components
execute if data entity @s Inventory[{Slot:1b}] run item replace entity @s hotbar.1 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:2b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,0.35d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:2b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:2b}].id
execute if data entity @s Inventory[{Slot:2b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:2b}].count
execute if data entity @s Inventory[{Slot:2b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:2b}].components
execute if data entity @s Inventory[{Slot:2b}] run item replace entity @s hotbar.2 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:3b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.25d,0.35d,0.25d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:3b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:3b}].id
execute if data entity @s Inventory[{Slot:3b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:3b}].count
execute if data entity @s Inventory[{Slot:3b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:3b}].components
execute if data entity @s Inventory[{Slot:3b}] run item replace entity @s hotbar.3 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:4b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:4b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:4b}].id
execute if data entity @s Inventory[{Slot:4b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:4b}].count
execute if data entity @s Inventory[{Slot:4b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:4b}].components
execute if data entity @s Inventory[{Slot:4b}] run item replace entity @s hotbar.4 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:5b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.25d,0.35d,-0.25d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:5b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:5b}].id
execute if data entity @s Inventory[{Slot:5b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:5b}].count
execute if data entity @s Inventory[{Slot:5b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:5b}].components
execute if data entity @s Inventory[{Slot:5b}] run item replace entity @s hotbar.5 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:6b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,-0.35d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:6b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:6b}].id
execute if data entity @s Inventory[{Slot:6b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:6b}].count
execute if data entity @s Inventory[{Slot:6b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:6b}].components
execute if data entity @s Inventory[{Slot:6b}] run item replace entity @s hotbar.6 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:7b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.25d,0.35d,-0.25d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:7b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:7b}].id
execute if data entity @s Inventory[{Slot:7b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:7b}].count
execute if data entity @s Inventory[{Slot:7b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:7b}].components
execute if data entity @s Inventory[{Slot:7b}] run item replace entity @s hotbar.7 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:8b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.2d,0.35d,0.3d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:8b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:8b}].id
execute if data entity @s Inventory[{Slot:8b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:8b}].count
execute if data entity @s Inventory[{Slot:8b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:8b}].components
execute if data entity @s Inventory[{Slot:8b}] run item replace entity @s hotbar.8 with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
