function tq:rng
scoreboard players operation #r tq_cfg = #rnd tq_cfg
scoreboard players operation #r tq_cfg %= #twelve tq_cfg
scoreboard players set #placed tq_cfg 0
execute if score #r tq_cfg matches 0 positioned ~4 ~ ~0 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 1 positioned ~-4 ~ ~0 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 2 positioned ~0 ~ ~4 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 3 positioned ~0 ~ ~-4 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 4 positioned ~3 ~ ~3 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 5 positioned ~-3 ~ ~3 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 6 positioned ~3 ~ ~-3 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 7 positioned ~-3 ~ ~-3 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 8 positioned ~6 ~ ~2 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 9 positioned ~-6 ~ ~-2 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 10 positioned ~2 ~ ~6 run function tq:penalty/mob_at
execute if score #r tq_cfg matches 11 positioned ~-2 ~ ~-6 run function tq:penalty/mob_at
execute if score #placed tq_cfg matches 0 run function tq:penalty/mob_summon
