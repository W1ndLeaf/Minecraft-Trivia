effect give @s minecraft:hunger 180 2 true
