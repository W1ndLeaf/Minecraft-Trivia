scoreboard players set #free tq_cfg 0
execute if block ~ ~ ~ minecraft:air if block ~ ~1 ~ minecraft:air run scoreboard players set #free tq_cfg 1
execute if block ~ ~ ~ minecraft:air if block ~ ~1 ~ minecraft:cave_air run scoreboard players set #free tq_cfg 1
execute if block ~ ~ ~ minecraft:cave_air if block ~ ~1 ~ minecraft:air run scoreboard players set #free tq_cfg 1
execute if block ~ ~ ~ minecraft:cave_air if block ~ ~1 ~ minecraft:cave_air run scoreboard players set #free tq_cfg 1
execute if score #free tq_cfg matches 1 run function tq:penalty/mob_summon
