title @s times 10 70 20
attribute @s minecraft:generic.scale base set 2
scoreboard players set @s tq_t_scale 180
title @s title {"text":"GIANT","color":"dark_red"}
title @s actionbar {"text":"double size for 3 min","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Giant - double size for 3 min.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
