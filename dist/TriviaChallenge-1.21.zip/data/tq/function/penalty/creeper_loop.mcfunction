scoreboard players add #i tq_cfg 1
scoreboard players set #mob tq_cfg 6
function tq:penalty/mob_place
execute if score #i tq_cfg matches ..3 run function tq:penalty/creeper_loop
