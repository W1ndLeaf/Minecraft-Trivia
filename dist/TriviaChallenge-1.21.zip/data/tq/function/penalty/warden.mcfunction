title @s times 10 70 20
playsound minecraft:entity.warden.emerge master @s ~ ~ ~ 1 1
summon minecraft:warden ~ ~ ~
title @s title {"text":"A WARDEN","color":"dark_red"}
title @s actionbar {"text":"good luck","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Warden - good luck.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
