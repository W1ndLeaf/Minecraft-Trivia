title @s times 10 70 20
attribute @s minecraft:player.block_interaction_range base set 2
scoreboard players set @s tq_t_reach 180
title @s title {"text":"SHORT ARMS","color":"dark_red"}
title @s actionbar {"text":"reach 2 blocks for 3 min","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Short arms - reach 2 blocks for 3 min.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
