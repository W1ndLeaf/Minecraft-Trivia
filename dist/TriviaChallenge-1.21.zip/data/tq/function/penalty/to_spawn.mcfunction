execute unless data storage tq:spawn x run tp @s ~ ~200 ~
execute if data storage tq:spawn x run function tq:penalty/to_spawn_tp with storage tq:spawn
