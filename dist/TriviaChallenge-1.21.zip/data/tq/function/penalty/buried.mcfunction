title @s times 10 70 20
function tq:penalty/buried_go
title @s title {"text":"BURIED ALIVE","color":"dark_red"}
title @s actionbar {"text":"15 blocks down","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Buried alive - 15 blocks down.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
