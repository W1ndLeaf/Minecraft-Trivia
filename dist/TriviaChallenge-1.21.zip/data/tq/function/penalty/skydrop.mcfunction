title @s times 10 70 20
tp @s ~ ~200 ~
title @s title {"text":"SKY DROP","color":"dark_red"}
title @s actionbar {"text":"200 blocks up","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Sky drop - 200 blocks up.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
