execute if score #placed tq_cfg matches 0 positioned ~ ~0 ~ run function tq:penalty/mob_try
execute if score #placed tq_cfg matches 0 positioned ~ ~1 ~ run function tq:penalty/mob_try
execute if score #placed tq_cfg matches 0 positioned ~ ~-1 ~ run function tq:penalty/mob_try
execute if score #placed tq_cfg matches 0 positioned ~ ~2 ~ run function tq:penalty/mob_try
execute if score #placed tq_cfg matches 0 positioned ~ ~-2 ~ run function tq:penalty/mob_try
