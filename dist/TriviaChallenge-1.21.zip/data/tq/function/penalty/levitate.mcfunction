title @s times 10 70 20
effect give @s minecraft:levitation 8 4 true
title @s title {"text":"LEVITATION V","color":"dark_red"}
title @s actionbar {"text":"8 seconds - going up, fast","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Levitation V - 8 seconds - going up, fast.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
