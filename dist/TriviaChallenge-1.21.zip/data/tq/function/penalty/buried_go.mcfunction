execute store result score #y tq_cfg run data get entity @s Pos[1]
scoreboard players set #ok tq_cfg 0
execute if predicate tq:overworld if score #y tq_cfg matches -40.. run scoreboard players set #ok tq_cfg 1
execute unless predicate tq:overworld if score #y tq_cfg matches 25.. run scoreboard players set #ok tq_cfg 1
execute if score #ok tq_cfg matches 1 run tp @s ~ ~-15 ~
execute if score #ok tq_cfg matches 0 run function tq:penalty/lost_go
