scoreboard players set #sum tq_cfg 0
execute if score p1 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p1 tq_w
execute if score p2 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p2 tq_w
execute if score p3 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p3 tq_w
execute if score p4 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p4 tq_w
execute if score p5 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p5 tq_w
execute if score p6 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p6 tq_w
execute if score p7 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p7 tq_w
execute if score p8 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p8 tq_w
execute if score p9 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p9 tq_w
execute if score p10 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p10 tq_w
execute if score p11 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p11 tq_w
execute if score p12 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p12 tq_w
execute if score p13 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p13 tq_w
execute if score p14 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p14 tq_w
execute if score p15 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p15 tq_w
execute if score p16 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p16 tq_w
execute if score p17 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p17 tq_w
execute if score p18 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p18 tq_w
execute if score p19 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p19 tq_w
execute if score p20 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p20 tq_w
execute if score p21 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p21 tq_w
execute if score p22 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p22 tq_w
execute if score p23 tq_on matches 1 run scoreboard players operation #sum tq_cfg += p23 tq_w
execute if score #sum tq_cfg matches ..0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"every punishment is switched off - nothing happens.","color":"yellow"}]}
execute if score #sum tq_cfg matches 1.. run function tq:penalty/roll
