scoreboard players add #i tq_cfg 1
function tq:penalty/mob_one
execute if score #i tq_cfg matches ..19 run function tq:penalty/mob_loop
