playsound minecraft:item.armor.equip_generic master @s ~ ~ ~ 1 0.5
execute if data entity @s Inventory[{Slot:103b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:103b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:103b}].id
execute if data entity @s Inventory[{Slot:103b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:103b}].count
execute if data entity @s Inventory[{Slot:103b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:103b}].components
execute if data entity @s Inventory[{Slot:103b}] run item replace entity @s armor.head with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:102b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,0.35d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:102b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:102b}].id
execute if data entity @s Inventory[{Slot:102b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:102b}].count
execute if data entity @s Inventory[{Slot:102b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:102b}].components
execute if data entity @s Inventory[{Slot:102b}] run item replace entity @s armor.chest with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:101b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:101b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:101b}].id
execute if data entity @s Inventory[{Slot:101b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:101b}].count
execute if data entity @s Inventory[{Slot:101b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:101b}].components
execute if data entity @s Inventory[{Slot:101b}] run item replace entity @s armor.legs with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:100b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,-0.35d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s Inventory[{Slot:100b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:100b}].id
execute if data entity @s Inventory[{Slot:100b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s Inventory[{Slot:100b}].count
execute if data entity @s Inventory[{Slot:100b}].components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s Inventory[{Slot:100b}].components
execute if data entity @s Inventory[{Slot:100b}] run item replace entity @s armor.feet with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
