title @s times 10 70 20
function tq:penalty/drop_hotbar
title @s title {"text":"BUTTERFINGERS","color":"dark_red"}
title @s actionbar {"text":"hotbar dropped","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Butterfingers - hotbar dropped.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
