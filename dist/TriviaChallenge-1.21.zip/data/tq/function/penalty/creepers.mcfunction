title @s times 10 70 20
scoreboard players set #i tq_cfg 0
function tq:penalty/creeper_loop
title @s title {"text":"CREEPER AMBUSH","color":"dark_red"}
title @s actionbar {"text":"4 charged creepers","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Creeper ambush - 4 charged creepers.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
