function tq:rng
scoreboard players operation #r tq_cfg = #rnd tq_cfg
scoreboard players operation #r tq_cfg %= #eight tq_cfg
execute if score #r tq_cfg matches 0 if predicate tq:overworld run spreadplayers ~0 ~-300 0 12 false @s
execute if score #r tq_cfg matches 0 unless predicate tq:overworld run spreadplayers ~0 ~-300 0 12 under 120 false @s
execute if score #r tq_cfg matches 1 if predicate tq:overworld run spreadplayers ~0 ~300 0 12 false @s
execute if score #r tq_cfg matches 1 unless predicate tq:overworld run spreadplayers ~0 ~300 0 12 under 120 false @s
execute if score #r tq_cfg matches 2 if predicate tq:overworld run spreadplayers ~-300 ~0 0 12 false @s
execute if score #r tq_cfg matches 2 unless predicate tq:overworld run spreadplayers ~-300 ~0 0 12 under 120 false @s
execute if score #r tq_cfg matches 3 if predicate tq:overworld run spreadplayers ~300 ~0 0 12 false @s
execute if score #r tq_cfg matches 3 unless predicate tq:overworld run spreadplayers ~300 ~0 0 12 under 120 false @s
execute if score #r tq_cfg matches 4 if predicate tq:overworld run spreadplayers ~212 ~212 0 12 false @s
execute if score #r tq_cfg matches 4 unless predicate tq:overworld run spreadplayers ~212 ~212 0 12 under 120 false @s
execute if score #r tq_cfg matches 5 if predicate tq:overworld run spreadplayers ~-212 ~212 0 12 false @s
execute if score #r tq_cfg matches 5 unless predicate tq:overworld run spreadplayers ~-212 ~212 0 12 under 120 false @s
execute if score #r tq_cfg matches 6 if predicate tq:overworld run spreadplayers ~212 ~-212 0 12 false @s
execute if score #r tq_cfg matches 6 unless predicate tq:overworld run spreadplayers ~212 ~-212 0 12 under 120 false @s
execute if score #r tq_cfg matches 7 if predicate tq:overworld run spreadplayers ~-212 ~-212 0 12 false @s
execute if score #r tq_cfg matches 7 unless predicate tq:overworld run spreadplayers ~-212 ~-212 0 12 under 120 false @s
