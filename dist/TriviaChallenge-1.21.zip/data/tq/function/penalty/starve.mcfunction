title @s times 10 70 20
effect give @s minecraft:hunger 3 254 true
function tq:penalty/starve2
title @s title {"text":"STARVATION","color":"dark_red"}
title @s actionbar {"text":"hunger drained + Hunger III 3 min","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Starvation - hunger drained + Hunger III 3 min.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
