title @s times 10 70 20
effect give @s minecraft:weakness 180 1 true
title @s title {"text":"FEEBLE","color":"dark_red"}
title @s actionbar {"text":"Weakness II for 3 min","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Feeble - Weakness II for 3 min.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
