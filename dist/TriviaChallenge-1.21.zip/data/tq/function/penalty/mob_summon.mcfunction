execute if score #mob tq_cfg matches 1 store success score #placed tq_cfg run summon minecraft:zombie ~ ~ ~
execute if score #mob tq_cfg matches 2 store success score #placed tq_cfg run summon minecraft:skeleton ~ ~ ~
execute if score #mob tq_cfg matches 3 store success score #placed tq_cfg run summon minecraft:creeper ~ ~ ~
execute if score #mob tq_cfg matches 4 store success score #placed tq_cfg run summon minecraft:spider ~ ~ ~
execute if score #mob tq_cfg matches 5 store success score #placed tq_cfg run summon minecraft:wither_skeleton ~ ~ ~
execute if score #mob tq_cfg matches 6 store success score #placed tq_cfg run summon minecraft:creeper ~ ~ ~ {powered:1b}
