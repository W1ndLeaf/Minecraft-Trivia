function tq:rng
scoreboard players operation #mob tq_cfg = #rnd tq_cfg
scoreboard players operation #mob tq_cfg %= #five tq_cfg
scoreboard players add #mob tq_cfg 1
function tq:penalty/mob_place
