title @s times 10 70 20
attribute @s minecraft:generic.jump_strength base set 0
scoreboard players set @s tq_t_jump 120
title @s title {"text":"GROUNDED","color":"dark_red"}
title @s actionbar {"text":"no jumping for 2 min","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Grounded - no jumping for 2 min.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
