title @s times 10 70 20
effect give @s minecraft:poison 30 1 true
title @s title {"text":"POISON II","color":"dark_red"}
title @s actionbar {"text":"30 seconds","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Poison II - 30 seconds.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
