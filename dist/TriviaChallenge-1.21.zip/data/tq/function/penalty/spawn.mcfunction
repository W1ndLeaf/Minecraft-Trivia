title @s times 10 70 20
function tq:penalty/to_spawn
title @s title {"text":"BACK TO SPAWN","color":"dark_red"}
title @s actionbar {"text":"where you first joined","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Back to spawn - where you first joined.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
