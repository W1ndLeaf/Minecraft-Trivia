title @s times 10 70 20
scoreboard players set #i tq_cfg 0
function tq:penalty/mob_loop
title @s title {"text":"MOB WAVE","color":"dark_red"}
title @s actionbar {"text":"20 hostile mobs","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Mob wave - 20 hostile mobs.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
