title @s times 10 70 20
function tq:penalty/drop_armor
title @s title {"text":"ARMOR STRIP","color":"dark_red"}
title @s actionbar {"text":"armor dropped","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Armor strip - armor dropped.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
