summon minecraft:phantom ~0 ~18 ~0
summon minecraft:phantom ~4 ~18 ~3
summon minecraft:phantom ~-4 ~18 ~3
summon minecraft:phantom ~3 ~18 ~-4
summon minecraft:phantom ~-3 ~18 ~-4
summon minecraft:phantom ~0 ~18 ~6
