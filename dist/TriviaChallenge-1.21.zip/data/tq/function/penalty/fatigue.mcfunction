title @s times 10 70 20
effect give @s minecraft:mining_fatigue 180 0 true
title @s title {"text":"MINING FATIGUE","color":"dark_red"}
title @s actionbar {"text":"3 min","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Mining Fatigue - 3 min.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
