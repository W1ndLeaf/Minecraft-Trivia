title @s times 10 70 20
effect give @s minecraft:slowness 120 1 true
title @s title {"text":"SLOWNESS II","color":"dark_red"}
title @s actionbar {"text":"2 min","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Slowness II - 2 min.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
