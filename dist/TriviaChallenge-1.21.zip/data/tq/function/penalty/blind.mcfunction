title @s times 10 70 20
effect give @s minecraft:blindness 60 0 true
title @s title {"text":"LIGHTS OUT","color":"dark_red"}
title @s actionbar {"text":"Blindness 1 min (no sprinting)","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Lights out - Blindness 1 min (no sprinting).  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
