execute if score #interval_min tq_cfg matches ..0 run scoreboard players set #interval_min tq_cfg 1
execute if score #interval_min tq_cfg matches 31.. run scoreboard players set #interval_min tq_cfg 30
scoreboard players operation #interval tq_cfg = #interval_min tq_cfg
scoreboard players operation #interval tq_cfg *= #1200 tq_cfg
function tq:interval_msg
