attribute @s minecraft:jump_strength base set 0.42
attribute @s minecraft:scale base set 1
attribute @s minecraft:block_interaction_range base set 4.5
attribute @s minecraft:fall_damage_multiplier base set 1
scoreboard players reset @s tq_t_jump
scoreboard players reset @s tq_t_scale
scoreboard players reset @s tq_t_reach
scoreboard players reset @s tq_t_fall
scoreboard players reset @s tq_tmp
