scoreboard players remove @s tq_t_jump 1
execute if score @s tq_t_jump matches ..0 run attribute @s minecraft:jump_strength base set 0.42
execute if score @s tq_t_jump matches ..0 run scoreboard players reset @s tq_t_jump
