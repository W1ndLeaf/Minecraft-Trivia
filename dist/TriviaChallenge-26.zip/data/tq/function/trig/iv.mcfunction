scoreboard players operation #interval_min tq_cfg = @s tq_iv
scoreboard players set @s tq_iv 0
scoreboard players enable @s tq_iv
function tq:set_interval
function tq:ui/options_show
