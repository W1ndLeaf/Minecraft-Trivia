scoreboard players operation #tmp tq_cfg = @s tq_ui
scoreboard players set @s tq_ui 0
scoreboard players enable @s tq_ui
execute if score #tmp tq_cfg matches 3 run function tq:ui/toggle_stats
execute if score #tmp tq_cfg matches 6 run function tq:ui/toggle_stats_opt
execute if score #tmp tq_cfg matches 5 run function tq:ui/toggle_diff
execute if score #tmp tq_cfg matches 4 run dialog clear @s
execute if score #tmp tq_cfg matches 11 run function tq:ui/all_r_on
execute if score #tmp tq_cfg matches 14 run function tq:ui/all_r_off
execute if score #tmp tq_cfg matches 12 run function tq:ui/all_p_on
execute if score #tmp tq_cfg matches 13 run function tq:ui/all_p_off
execute if score #tmp tq_cfg matches 101..118 run function tq:ui/tog_r
execute if score #tmp tq_cfg matches 201..223 run function tq:ui/tog_p
