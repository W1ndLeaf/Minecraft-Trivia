gamerule send_command_feedback false
gamerule log_admin_commands false
scoreboard players set #fb_set tq_cfg 1
