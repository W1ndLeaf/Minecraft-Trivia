function tq:all_p_off
function tq:ui/punishments_show
