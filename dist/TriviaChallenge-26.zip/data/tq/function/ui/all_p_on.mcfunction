function tq:all_p_on
function tq:ui/punishments_show
