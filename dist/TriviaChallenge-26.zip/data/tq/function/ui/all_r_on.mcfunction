function tq:all_r_on
function tq:ui/rewards_show
