function tq:toggle_stats
function tq:ui/options_show
