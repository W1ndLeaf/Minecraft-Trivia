function tq:all_r_off
function tq:ui/rewards_show
