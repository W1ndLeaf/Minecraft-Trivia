function tq:toggle_stats
function tq:ui/menu_show
