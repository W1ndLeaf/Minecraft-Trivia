scoreboard players set #tmp tq_cfg 1
execute if score #diff tq_cfg matches 1 run scoreboard players set #tmp tq_cfg 2
function tq:set_diff
function tq:ui/options_show
