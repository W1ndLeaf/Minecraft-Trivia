title @s times 10 70 20
title @s subtitle {"text":"reach +2 blocks for 3 minutes","color":"white"}
attribute @s minecraft:block_interaction_range base set 6.5
scoreboard players set @s tq_t_reach 180
title @s title {"text":"Long arms","color":"gold"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Long arms - reach +2 blocks for 3 minutes","color":"green"}]
