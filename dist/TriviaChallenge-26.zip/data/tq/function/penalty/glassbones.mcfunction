title @s times 10 70 20
attribute @s minecraft:fall_damage_multiplier base set 3
scoreboard players set @s tq_t_fall 300
title @s title {"text":"GLASS BONES","color":"dark_red"}
title @s actionbar {"text":"fall damage x3 for 5 min","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Glass bones - fall damage x3 for 5 min.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
