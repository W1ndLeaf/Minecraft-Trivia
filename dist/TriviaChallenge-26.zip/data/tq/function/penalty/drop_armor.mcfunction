playsound minecraft:item.armor.equip_generic master @s ~ ~ ~ 1 0.5
execute if data entity @s equipment.head run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s equipment.head run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s equipment.head.id
execute if data entity @s equipment.head run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s equipment.head.count
execute if data entity @s equipment.head.components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s equipment.head.components
execute if data entity @s equipment.head run item replace entity @s armor.head with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s equipment.chest run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,0.35d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s equipment.chest run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s equipment.chest.id
execute if data entity @s equipment.chest run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s equipment.chest.count
execute if data entity @s equipment.chest.components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s equipment.chest.components
execute if data entity @s equipment.chest run item replace entity @s armor.chest with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s equipment.legs run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s equipment.legs run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s equipment.legs.id
execute if data entity @s equipment.legs run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s equipment.legs.count
execute if data entity @s equipment.legs.components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s equipment.legs.components
execute if data entity @s equipment.legs run item replace entity @s armor.legs with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s equipment.feet run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,-0.35d],Item:{id:"minecraft:stone",count:1}}
execute if data entity @s equipment.feet run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s equipment.feet.id
execute if data entity @s equipment.feet run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.count set from entity @s equipment.feet.count
execute if data entity @s equipment.feet.components run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.components set from entity @s equipment.feet.components
execute if data entity @s equipment.feet run item replace entity @s armor.feet with minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
