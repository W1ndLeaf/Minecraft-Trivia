scoreboard players add #clock tq_cfg 1
execute as @a[scores={tq_leave=1..}] run function tq:on_join
execute as @a[tag=!tq_init] at @s run function tq:first_join
execute as @a[scores={tq_deaths=1..}] run function tq:on_death
execute as @a[scores={tq_delay=1..}] run function tq:delay_tick
execute as @a[scores={tq_ask=1..}] at @s run function tq:trig/ask
execute as @a[scores={tq_interval=1..}] at @s run function tq:trig/interval
execute as @a[scores={tq_menu=1..}] at @s run function tq:trig/menu
execute as @a[scores={tq_opts=1..}] at @s run function tq:trig/opts
execute as @a[scores={tq_diff=1..}] at @s run function tq:trig/diff
execute as @a[scores={tq_stats=1..}] at @s run function tq:trig/stats
execute as @a[scores={tq_rl=1..}] at @s run function tq:trig/rl
execute as @a[scores={tq_pl=1..}] at @s run function tq:trig/pl
execute as @a[scores={tq_tr=1..}] at @s run function tq:trig/tr
execute as @a[scores={tq_tp=1..}] at @s run function tq:trig/tp
execute as @a[scores={tq_status=1..}] at @s run function tq:trig/status
execute as @a[scores={tq_ui=1..}] at @s run function tq:trig/ui
execute as @a[scores={tq_iv=1..}] at @s run function tq:trig/iv
execute as @a[scores={tq_state=0,tq_answer=1..}] run scoreboard players set @s tq_answer 0
execute as @a[scores={tq_state=1,tq_answer=1..}] at @s run function tq:answered
execute as @a[scores={tq_state=0,tq_health=1..},gamemode=!spectator] at @s run function tq:timer_tick
execute as @a[scores={tq_state=1..}] run function tq:wait_tick
execute if score #clock tq_cfg matches 20.. run function tq:second
