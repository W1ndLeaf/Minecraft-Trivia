scoreboard players reset @s tq_tmp
