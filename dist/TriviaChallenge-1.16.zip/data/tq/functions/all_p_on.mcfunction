scoreboard players set p1 tq_on 1
scoreboard players set p2 tq_on 1
scoreboard players set p3 tq_on 1
scoreboard players set p4 tq_on 1
scoreboard players set p5 tq_on 1
scoreboard players set p6 tq_on 1
scoreboard players set p7 tq_on 1
scoreboard players set p8 tq_on 1
scoreboard players set p9 tq_on 1
scoreboard players set p10 tq_on 1
scoreboard players set p11 tq_on 1
scoreboard players set p12 tq_on 1
scoreboard players set p13 tq_on 1
scoreboard players set p14 tq_on 1
scoreboard players set p15 tq_on 1
scoreboard players set p16 tq_on 1
scoreboard players set p17 tq_on 1
scoreboard players set p18 tq_on 1
title @s actionbar {"text":"Every punishment is ON","color":"green"}
tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"every punishment is ON.","color":"green"}]}
