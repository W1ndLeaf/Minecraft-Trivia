playsound minecraft:entity.item.pickup master @s ~ ~ ~ 1 0.5
execute if data entity @s Inventory[{Slot:0b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:0b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:0b}].id
execute if data entity @s Inventory[{Slot:0b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:0b}].Count
execute if data entity @s Inventory[{Slot:0b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:0b}].tag
execute if data entity @s Inventory[{Slot:0b}] run replaceitem entity @s hotbar.0 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:1b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.25d,0.35d,0.25d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:1b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:1b}].id
execute if data entity @s Inventory[{Slot:1b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:1b}].Count
execute if data entity @s Inventory[{Slot:1b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:1b}].tag
execute if data entity @s Inventory[{Slot:1b}] run replaceitem entity @s hotbar.1 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:2b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,0.35d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:2b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:2b}].id
execute if data entity @s Inventory[{Slot:2b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:2b}].Count
execute if data entity @s Inventory[{Slot:2b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:2b}].tag
execute if data entity @s Inventory[{Slot:2b}] run replaceitem entity @s hotbar.2 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:3b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.25d,0.35d,0.25d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:3b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:3b}].id
execute if data entity @s Inventory[{Slot:3b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:3b}].Count
execute if data entity @s Inventory[{Slot:3b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:3b}].tag
execute if data entity @s Inventory[{Slot:3b}] run replaceitem entity @s hotbar.3 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:4b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:4b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:4b}].id
execute if data entity @s Inventory[{Slot:4b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:4b}].Count
execute if data entity @s Inventory[{Slot:4b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:4b}].tag
execute if data entity @s Inventory[{Slot:4b}] run replaceitem entity @s hotbar.4 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:5b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.25d,0.35d,-0.25d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:5b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:5b}].id
execute if data entity @s Inventory[{Slot:5b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:5b}].Count
execute if data entity @s Inventory[{Slot:5b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:5b}].tag
execute if data entity @s Inventory[{Slot:5b}] run replaceitem entity @s hotbar.5 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:6b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,-0.35d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:6b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:6b}].id
execute if data entity @s Inventory[{Slot:6b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:6b}].Count
execute if data entity @s Inventory[{Slot:6b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:6b}].tag
execute if data entity @s Inventory[{Slot:6b}] run replaceitem entity @s hotbar.6 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:7b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.25d,0.35d,-0.25d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:7b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:7b}].id
execute if data entity @s Inventory[{Slot:7b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:7b}].Count
execute if data entity @s Inventory[{Slot:7b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:7b}].tag
execute if data entity @s Inventory[{Slot:7b}] run replaceitem entity @s hotbar.7 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:8b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.2d,0.35d,0.3d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:8b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:8b}].id
execute if data entity @s Inventory[{Slot:8b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:8b}].Count
execute if data entity @s Inventory[{Slot:8b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:8b}].tag
execute if data entity @s Inventory[{Slot:8b}] run replaceitem entity @s hotbar.8 minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
