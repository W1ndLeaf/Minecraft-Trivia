playsound minecraft:item.armor.equip_generic master @s ~ ~ ~ 1 0.5
execute if data entity @s Inventory[{Slot:103b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:103b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:103b}].id
execute if data entity @s Inventory[{Slot:103b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:103b}].Count
execute if data entity @s Inventory[{Slot:103b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:103b}].tag
execute if data entity @s Inventory[{Slot:103b}] run replaceitem entity @s armor.head minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:102b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,0.35d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:102b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:102b}].id
execute if data entity @s Inventory[{Slot:102b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:102b}].Count
execute if data entity @s Inventory[{Slot:102b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:102b}].tag
execute if data entity @s Inventory[{Slot:102b}] run replaceitem entity @s armor.chest minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:101b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[-0.35d,0.35d,0.0d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:101b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:101b}].id
execute if data entity @s Inventory[{Slot:101b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:101b}].Count
execute if data entity @s Inventory[{Slot:101b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:101b}].tag
execute if data entity @s Inventory[{Slot:101b}] run replaceitem entity @s armor.legs minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
execute if data entity @s Inventory[{Slot:100b}] run summon minecraft:item ~ ~1 ~ {Tags:["tq_drop"],PickupDelay:60s,Motion:[0.0d,0.35d,-0.35d],Item:{id:"minecraft:stone",Count:1b}}
execute if data entity @s Inventory[{Slot:100b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.id set from entity @s Inventory[{Slot:100b}].id
execute if data entity @s Inventory[{Slot:100b}] run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.Count set from entity @s Inventory[{Slot:100b}].Count
execute if data entity @s Inventory[{Slot:100b}].tag run data modify entity @e[type=item,tag=tq_drop,limit=1,sort=nearest] Item.tag set from entity @s Inventory[{Slot:100b}].tag
execute if data entity @s Inventory[{Slot:100b}] run replaceitem entity @s armor.feet minecraft:air
tag @e[type=item,tag=tq_drop] remove tq_drop
