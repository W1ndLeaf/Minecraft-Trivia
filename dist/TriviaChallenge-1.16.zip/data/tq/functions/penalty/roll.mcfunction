function tq:rng
scoreboard players operation #roll tq_cfg = #rnd tq_cfg
scoreboard players operation #roll tq_cfg %= #sum tq_cfg
scoreboard players add #roll tq_cfg 1
scoreboard players set #acc tq_cfg 0
scoreboard players set #pick tq_cfg 0
execute if score #pick tq_cfg matches 0 if score p1 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p1 tq_w
execute if score #pick tq_cfg matches 0 if score p1 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 1
execute if score #pick tq_cfg matches 0 if score p2 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p2 tq_w
execute if score #pick tq_cfg matches 0 if score p2 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 2
execute if score #pick tq_cfg matches 0 if score p3 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p3 tq_w
execute if score #pick tq_cfg matches 0 if score p3 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 3
execute if score #pick tq_cfg matches 0 if score p4 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p4 tq_w
execute if score #pick tq_cfg matches 0 if score p4 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 4
execute if score #pick tq_cfg matches 0 if score p5 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p5 tq_w
execute if score #pick tq_cfg matches 0 if score p5 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 5
execute if score #pick tq_cfg matches 0 if score p6 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p6 tq_w
execute if score #pick tq_cfg matches 0 if score p6 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 6
execute if score #pick tq_cfg matches 0 if score p7 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p7 tq_w
execute if score #pick tq_cfg matches 0 if score p7 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 7
execute if score #pick tq_cfg matches 0 if score p8 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p8 tq_w
execute if score #pick tq_cfg matches 0 if score p8 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 8
execute if score #pick tq_cfg matches 0 if score p9 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p9 tq_w
execute if score #pick tq_cfg matches 0 if score p9 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 9
execute if score #pick tq_cfg matches 0 if score p10 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p10 tq_w
execute if score #pick tq_cfg matches 0 if score p10 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 10
execute if score #pick tq_cfg matches 0 if score p11 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p11 tq_w
execute if score #pick tq_cfg matches 0 if score p11 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 11
execute if score #pick tq_cfg matches 0 if score p12 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p12 tq_w
execute if score #pick tq_cfg matches 0 if score p12 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 12
execute if score #pick tq_cfg matches 0 if score p13 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p13 tq_w
execute if score #pick tq_cfg matches 0 if score p13 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 13
execute if score #pick tq_cfg matches 0 if score p14 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p14 tq_w
execute if score #pick tq_cfg matches 0 if score p14 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 14
execute if score #pick tq_cfg matches 0 if score p15 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p15 tq_w
execute if score #pick tq_cfg matches 0 if score p15 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 15
execute if score #pick tq_cfg matches 0 if score p16 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p16 tq_w
execute if score #pick tq_cfg matches 0 if score p16 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 16
execute if score #pick tq_cfg matches 0 if score p17 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p17 tq_w
execute if score #pick tq_cfg matches 0 if score p17 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 17
execute if score #pick tq_cfg matches 0 if score p18 tq_on matches 1 run scoreboard players operation #acc tq_cfg += p18 tq_w
execute if score #pick tq_cfg matches 0 if score p18 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 18
execute if score #pick tq_cfg matches 1 run scoreboard players operation p1 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 1 if score p1 tq_w matches ..0 run scoreboard players set p1 tq_w 1
execute if score #pick tq_cfg matches 2 run scoreboard players operation p2 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 2 if score p2 tq_w matches ..0 run scoreboard players set p2 tq_w 1
execute if score #pick tq_cfg matches 3 run scoreboard players operation p3 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 3 if score p3 tq_w matches ..0 run scoreboard players set p3 tq_w 1
execute if score #pick tq_cfg matches 4 run scoreboard players operation p4 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 4 if score p4 tq_w matches ..0 run scoreboard players set p4 tq_w 1
execute if score #pick tq_cfg matches 5 run scoreboard players operation p5 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 5 if score p5 tq_w matches ..0 run scoreboard players set p5 tq_w 1
execute if score #pick tq_cfg matches 6 run scoreboard players operation p6 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 6 if score p6 tq_w matches ..0 run scoreboard players set p6 tq_w 1
execute if score #pick tq_cfg matches 7 run scoreboard players operation p7 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 7 if score p7 tq_w matches ..0 run scoreboard players set p7 tq_w 1
execute if score #pick tq_cfg matches 8 run scoreboard players operation p8 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 8 if score p8 tq_w matches ..0 run scoreboard players set p8 tq_w 1
execute if score #pick tq_cfg matches 9 run scoreboard players operation p9 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 9 if score p9 tq_w matches ..0 run scoreboard players set p9 tq_w 1
execute if score #pick tq_cfg matches 10 run scoreboard players operation p10 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 10 if score p10 tq_w matches ..0 run scoreboard players set p10 tq_w 1
execute if score #pick tq_cfg matches 11 run scoreboard players operation p11 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 11 if score p11 tq_w matches ..0 run scoreboard players set p11 tq_w 1
execute if score #pick tq_cfg matches 12 run scoreboard players operation p12 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 12 if score p12 tq_w matches ..0 run scoreboard players set p12 tq_w 1
execute if score #pick tq_cfg matches 13 run scoreboard players operation p13 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 13 if score p13 tq_w matches ..0 run scoreboard players set p13 tq_w 1
execute if score #pick tq_cfg matches 14 run scoreboard players operation p14 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 14 if score p14 tq_w matches ..0 run scoreboard players set p14 tq_w 1
execute if score #pick tq_cfg matches 15 run scoreboard players operation p15 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 15 if score p15 tq_w matches ..0 run scoreboard players set p15 tq_w 1
execute if score #pick tq_cfg matches 16 run scoreboard players operation p16 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 16 if score p16 tq_w matches ..0 run scoreboard players set p16 tq_w 1
execute if score #pick tq_cfg matches 17 run scoreboard players operation p17 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 17 if score p17 tq_w matches ..0 run scoreboard players set p17 tq_w 1
execute if score #pick tq_cfg matches 18 run scoreboard players operation p18 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 18 if score p18 tq_w matches ..0 run scoreboard players set p18 tq_w 1
execute if score #pick tq_cfg matches 1 run function tq:penalty/slow
execute if score #pick tq_cfg matches 2 run function tq:penalty/fatigue
execute if score #pick tq_cfg matches 3 run function tq:penalty/levitate
execute if score #pick tq_cfg matches 4 run function tq:penalty/lost
execute if score #pick tq_cfg matches 5 run function tq:penalty/mobs
execute if score #pick tq_cfg matches 6 run function tq:penalty/skydrop
execute if score #pick tq_cfg matches 7 run function tq:penalty/wither
execute if score #pick tq_cfg matches 8 run function tq:penalty/starve
execute if score #pick tq_cfg matches 9 run function tq:penalty/blind
execute if score #pick tq_cfg matches 10 run function tq:penalty/butterfingers
execute if score #pick tq_cfg matches 11 run function tq:penalty/spawn
execute if score #pick tq_cfg matches 12 run function tq:penalty/poison
execute if score #pick tq_cfg matches 13 run function tq:penalty/feeble
execute if score #pick tq_cfg matches 14 run function tq:penalty/phantoms
execute if score #pick tq_cfg matches 15 run function tq:penalty/creepers
execute if score #pick tq_cfg matches 16 run function tq:penalty/armorstrip
execute if score #pick tq_cfg matches 17 run function tq:penalty/toolbreak
execute if score #pick tq_cfg matches 18 run function tq:penalty/buried
