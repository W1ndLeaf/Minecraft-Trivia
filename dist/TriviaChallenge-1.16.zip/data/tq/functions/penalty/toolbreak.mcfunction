title @s times 10 70 20
playsound minecraft:entity.item.break master @s ~ ~ ~ 1 1
replaceitem entity @s weapon.mainhand minecraft:air
title @s title {"text":"TOOL BREAK","color":"dark_red"}
title @s actionbar {"text":"main hand destroyed","color":"red"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Punishment: Tool break - main hand destroyed.  ","color":"red"},{"text":"Correct: ","color":"yellow"},{"nbt":"ansfull","storage":"tq:tmp","color":"white"}]
