execute in minecraft:overworld if entity @e[type=minecraft:area_effect_cloud,tag=tq_spawn] run tp @s @e[type=minecraft:area_effect_cloud,tag=tq_spawn,limit=1]
execute in minecraft:overworld unless entity @e[type=minecraft:area_effect_cloud,tag=tq_spawn] run tp @s ~ ~200 ~
