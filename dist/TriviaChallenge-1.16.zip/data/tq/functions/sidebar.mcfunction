scoreboard players operation #m tq_cfg = #interval tq_cfg
scoreboard players operation #m tq_cfg -= @s tq_timer
scoreboard players operation #m tq_cfg /= #1200 tq_cfg
scoreboard players add #m tq_cfg 1
execute unless score @s tq_state matches 0 run scoreboard players set #m tq_cfg 0
scoreboard players operation minutes tq_score = #m tq_cfg
scoreboard players operation Correct tq_score = @s tq_right
scoreboard players operation Wrong tq_score = @s tq_wrong
