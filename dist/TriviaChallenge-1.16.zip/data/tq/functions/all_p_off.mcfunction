scoreboard players set p1 tq_on 0
scoreboard players set p2 tq_on 0
scoreboard players set p3 tq_on 0
scoreboard players set p4 tq_on 0
scoreboard players set p5 tq_on 0
scoreboard players set p6 tq_on 0
scoreboard players set p7 tq_on 0
scoreboard players set p8 tq_on 0
scoreboard players set p9 tq_on 0
scoreboard players set p10 tq_on 0
scoreboard players set p11 tq_on 0
scoreboard players set p12 tq_on 0
scoreboard players set p13 tq_on 0
scoreboard players set p14 tq_on 0
scoreboard players set p15 tq_on 0
scoreboard players set p16 tq_on 0
scoreboard players set p17 tq_on 0
scoreboard players set p18 tq_on 0
title @s actionbar {"text":"Every punishment is OFF","color":"red"}
tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"every punishment is OFF - that side does nothing now.","color":"red"}]}
