title @s times 10 70 20
title @s subtitle {"text":"permanent for this world","color":"white"}
tag @s add tq_e_sf
effect give @s minecraft:slow_falling 1000000 0 true
title @s title {"text":"Slow Falling","color":"aqua"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Slow Falling - permanent for this world","color":"green"}]
