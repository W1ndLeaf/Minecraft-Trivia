title @s times 10 70 20
title @s subtitle {"text":"permanent for this world","color":"white"}
tag @s add tq_e_nv
effect give @s minecraft:night_vision 1000000 0 true
title @s title {"text":"Night Vision","color":"aqua"}
tellraw @s [{"text":"[Trivia] ","color":"gold"},{"text":"Reward: Night Vision - permanent for this world","color":"green"}]
