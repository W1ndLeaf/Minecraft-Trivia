function tq:rng
scoreboard players operation #roll tq_cfg = #rnd tq_cfg
scoreboard players operation #roll tq_cfg %= #sum tq_cfg
scoreboard players add #roll tq_cfg 1
scoreboard players set #acc tq_cfg 0
scoreboard players set #pick tq_cfg 0
execute if score #pick tq_cfg matches 0 if score r1 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r1 tq_w
execute if score #pick tq_cfg matches 0 if score r1 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 1
execute if score #pick tq_cfg matches 0 if score r2 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r2 tq_w
execute if score #pick tq_cfg matches 0 if score r2 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 2
execute if score #pick tq_cfg matches 0 if score r3 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r3 tq_w
execute if score #pick tq_cfg matches 0 if score r3 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 3
execute if score #pick tq_cfg matches 0 if score r4 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r4 tq_w
execute if score #pick tq_cfg matches 0 if score r4 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 4
execute if score #pick tq_cfg matches 0 if score r5 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r5 tq_w
execute if score #pick tq_cfg matches 0 if score r5 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 5
execute if score #pick tq_cfg matches 0 if score r6 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r6 tq_w
execute if score #pick tq_cfg matches 0 if score r6 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 6
execute if score #pick tq_cfg matches 0 if score r7 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r7 tq_w
execute if score #pick tq_cfg matches 0 if score r7 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 7
execute if score #pick tq_cfg matches 0 if score r8 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r8 tq_w
execute if score #pick tq_cfg matches 0 if score r8 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 8
execute if score #pick tq_cfg matches 0 if score r9 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r9 tq_w
execute if score #pick tq_cfg matches 0 if score r9 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 9
execute if score #pick tq_cfg matches 0 if score r10 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r10 tq_w
execute if score #pick tq_cfg matches 0 if score r10 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 10
execute if score #pick tq_cfg matches 0 if score r11 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r11 tq_w
execute if score #pick tq_cfg matches 0 if score r11 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 11
execute if score #pick tq_cfg matches 0 if score r12 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r12 tq_w
execute if score #pick tq_cfg matches 0 if score r12 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 12
execute if score #pick tq_cfg matches 0 if score r13 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r13 tq_w
execute if score #pick tq_cfg matches 0 if score r13 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 13
execute if score #pick tq_cfg matches 0 if score r14 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r14 tq_w
execute if score #pick tq_cfg matches 0 if score r14 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 14
execute if score #pick tq_cfg matches 0 if score r15 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r15 tq_w
execute if score #pick tq_cfg matches 0 if score r15 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 15
execute if score #pick tq_cfg matches 0 if score r16 tq_on matches 1 run scoreboard players operation #acc tq_cfg += r16 tq_w
execute if score #pick tq_cfg matches 0 if score r16 tq_on matches 1 if score #roll tq_cfg <= #acc tq_cfg run scoreboard players set #pick tq_cfg 16
execute if score #pick tq_cfg matches 1 run scoreboard players operation r1 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 1 if score r1 tq_w matches ..0 run scoreboard players set r1 tq_w 1
execute if score #pick tq_cfg matches 2 run scoreboard players operation r2 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 2 if score r2 tq_w matches ..0 run scoreboard players set r2 tq_w 1
execute if score #pick tq_cfg matches 3 run scoreboard players operation r3 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 3 if score r3 tq_w matches ..0 run scoreboard players set r3 tq_w 1
execute if score #pick tq_cfg matches 4 run scoreboard players operation r4 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 4 if score r4 tq_w matches ..0 run scoreboard players set r4 tq_w 1
execute if score #pick tq_cfg matches 5 run scoreboard players operation r5 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 5 if score r5 tq_w matches ..0 run scoreboard players set r5 tq_w 1
execute if score #pick tq_cfg matches 6 run scoreboard players operation r6 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 6 if score r6 tq_w matches ..0 run scoreboard players set r6 tq_w 1
execute if score #pick tq_cfg matches 7 run scoreboard players operation r7 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 7 if score r7 tq_w matches ..0 run scoreboard players set r7 tq_w 1
execute if score #pick tq_cfg matches 8 run scoreboard players operation r8 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 8 if score r8 tq_w matches ..0 run scoreboard players set r8 tq_w 1
execute if score #pick tq_cfg matches 9 run scoreboard players operation r9 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 9 if score r9 tq_w matches ..0 run scoreboard players set r9 tq_w 1
execute if score #pick tq_cfg matches 10 run scoreboard players operation r10 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 10 if score r10 tq_w matches ..0 run scoreboard players set r10 tq_w 1
execute if score #pick tq_cfg matches 11 run scoreboard players operation r11 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 11 if score r11 tq_w matches ..0 run scoreboard players set r11 tq_w 1
execute if score #pick tq_cfg matches 12 run scoreboard players operation r12 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 12 if score r12 tq_w matches ..0 run scoreboard players set r12 tq_w 1
execute if score #pick tq_cfg matches 13 run scoreboard players operation r13 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 13 if score r13 tq_w matches ..0 run scoreboard players set r13 tq_w 1
execute if score #pick tq_cfg matches 14 run scoreboard players operation r14 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 14 if score r14 tq_w matches ..0 run scoreboard players set r14 tq_w 1
execute if score #pick tq_cfg matches 15 run scoreboard players operation r15 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 15 if score r15 tq_w matches ..0 run scoreboard players set r15 tq_w 1
execute if score #pick tq_cfg matches 16 run scoreboard players operation r16 tq_w /= #two tq_cfg
execute if score #pick tq_cfg matches 16 if score r16 tq_w matches ..0 run scoreboard players set r16 tq_w 1
execute if score #pick tq_cfg matches 1 run function tq:reward/tools
execute if score #pick tq_cfg matches 2 run function tq:reward/nightvision
execute if score #pick tq_cfg matches 3 run function tq:reward/slowfall
execute if score #pick tq_cfg matches 4 run function tq:reward/spawn
execute if score #pick tq_cfg matches 5 run function tq:reward/heart
execute if score #pick tq_cfg matches 6 run function tq:reward/belly
execute if score #pick tq_cfg matches 7 run function tq:reward/regen
execute if score #pick tq_cfg matches 8 run function tq:reward/cobble
execute if score #pick tq_cfg matches 9 run function tq:reward/shield
execute if score #pick tq_cfg matches 10 run function tq:reward/pickaxe
execute if score #pick tq_cfg matches 11 run function tq:reward/freeze
execute if score #pick tq_cfg matches 12 run function tq:reward/item
execute if score #pick tq_cfg matches 13 run function tq:reward/bow
execute if score #pick tq_cfg matches 14 run function tq:reward/fireres
execute if score #pick tq_cfg matches 15 run function tq:reward/haste
execute if score #pick tq_cfg matches 16 run function tq:reward/speed
