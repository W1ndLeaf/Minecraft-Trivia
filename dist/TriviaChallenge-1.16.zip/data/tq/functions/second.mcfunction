scoreboard players set #clock tq_cfg 0
function tq:enable_triggers
execute as @a[tag=tq_e_nv] run effect give @s minecraft:night_vision 1000000 0 true
execute as @a[tag=tq_e_sf] run effect give @s minecraft:slow_falling 1000000 0 true
execute if score #freeze tq_cfg matches 1.. run function tq:freeze/tick
execute if score #sidebar tq_cfg matches 1 as @a[limit=1] run function tq:sidebar
