scoreboard players operation #f tq_cfg = p10 tq_on
execute if score #f tq_cfg matches 1 run scoreboard players set p10 tq_on 0
execute if score #f tq_cfg matches 0 run scoreboard players set p10 tq_on 1
execute if score p10 tq_on matches 1 run title @s actionbar {"text":"Punishment: Butterfingers is ON","color":"green"}
execute if score p10 tq_on matches 0 run title @s actionbar {"text":"Punishment: Butterfingers is OFF","color":"red"}
execute if score p10 tq_on matches 1 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Punishment Butterfingers: ON","color":"green"}]}
execute if score p10 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Punishment Butterfingers: OFF","color":"red"}]}
