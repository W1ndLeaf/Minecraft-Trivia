tag @s add tq_init
scoreboard players set @s tq_state 0
scoreboard players set @s tq_timer 0
scoreboard players set @s tq_wait 0
scoreboard players set @s tq_leave 0
execute unless score @s tq_right matches 0.. run scoreboard players set @s tq_right 0
execute unless score @s tq_wrong matches 0.. run scoreboard players set @s tq_wrong 0
execute unless score #spawn_set tq_cfg matches 1 run summon minecraft:area_effect_cloud ~ ~ ~ {Tags:["tq_spawn"],Duration:2147483647,Age:-2147483648,WaitTime:-2147483648,Radius:0.0f}
scoreboard players set #spawn_set tq_cfg 1
tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"Welcome! ","color":"gray"},{"text":"/trigger tq_menu","color":"yellow"},{"text":" = menu and options, ","color":"gray"},{"text":"/trigger tq_ask","color":"yellow"},{"text":" = a question now.","color":"gray"}]}
