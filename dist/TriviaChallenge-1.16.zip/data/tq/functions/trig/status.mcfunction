scoreboard players set @s tq_status 0
scoreboard players enable @s tq_status
scoreboard players set #off tq_cfg 0
tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"---- status ----","color":"gold"}]}
execute if score #diff tq_cfg matches 1 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"difficulty: NORMAL.","color":"gray"}]}
execute if score #diff tq_cfg matches 2 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"difficulty: HARD.","color":"gray"}]}
function tq:interval_msg
execute if score #sidebar tq_cfg matches 1 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"score display: on.","color":"gray"}]}
execute if score #sidebar tq_cfg matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"score display: off.","color":"gray"}]}
execute if score r1 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r1 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Classic tools","color":"red"}]}
execute if score r2 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r2 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Night Vision","color":"red"}]}
execute if score r3 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r3 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Slow Falling","color":"red"}]}
execute if score r4 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r4 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Safe spawn","color":"red"}]}
execute if score r5 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r5 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: +1 heart","color":"red"}]}
execute if score r6 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r6 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Full belly","color":"red"}]}
execute if score r7 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r7 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Second wind","color":"red"}]}
execute if score r8 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r8 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: 64 Cobblestone","color":"red"}]}
execute if score r9 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r9 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Shield","color":"red"}]}
execute if score r10 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r10 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Iron pickaxe","color":"red"}]}
execute if score r11 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r11 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Time freeze","color":"red"}]}
execute if score r12 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r12 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Useful item","color":"red"}]}
execute if score r13 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r13 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Bow + arrows","color":"red"}]}
execute if score r14 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r14 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Fire Res 3 min","color":"red"}]}
execute if score r15 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r15 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Haste 3 min","color":"red"}]}
execute if score r16 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score r16 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"reward OFF: Speed 3 min","color":"red"}]}
execute if score p1 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p1 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Slowness II","color":"red"}]}
execute if score p2 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p2 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Mining Fatigue","color":"red"}]}
execute if score p3 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p3 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Levitation V","color":"red"}]}
execute if score p4 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p4 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Lost","color":"red"}]}
execute if score p5 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p5 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Mob wave","color":"red"}]}
execute if score p6 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p6 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Sky drop","color":"red"}]}
execute if score p7 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p7 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Wither","color":"red"}]}
execute if score p8 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p8 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Starvation","color":"red"}]}
execute if score p9 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p9 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Lights out","color":"red"}]}
execute if score p10 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p10 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Butterfingers","color":"red"}]}
execute if score p11 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p11 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Back to spawn","color":"red"}]}
execute if score p12 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p12 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Poison II","color":"red"}]}
execute if score p13 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p13 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Feeble","color":"red"}]}
execute if score p14 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p14 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Phantom night","color":"red"}]}
execute if score p15 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p15 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Creeper ambush","color":"red"}]}
execute if score p16 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p16 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Armor strip","color":"red"}]}
execute if score p17 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p17 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Tool break","color":"red"}]}
execute if score p18 tq_on matches 0 run scoreboard players add #off tq_cfg 1
execute if score p18 tq_on matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"punishment OFF: Buried alive","color":"red"}]}
execute if score #off tq_cfg matches 0 run tellraw @s {"text":"[Trivia] ","color":"gold","extra":[{"text":"every reward and punishment is ON.","color":"green"}]}
