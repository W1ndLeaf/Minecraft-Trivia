execute at @s run summon minecraft:area_effect_cloud ~ ~ ~ {Tags:["tq_rng"],Duration:1}
execute store result score #rnd tq_cfg run data get entity @e[type=minecraft:area_effect_cloud,tag=tq_rng,limit=1] UUID[0]
kill @e[type=minecraft:area_effect_cloud,tag=tq_rng]
